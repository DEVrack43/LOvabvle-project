
Objetivo
- Conseguir que “Crear grupo” funcione siempre (el usuario se encuentra por email, pero el grupo no aparece/“no se crea”).
- Hacer que cuando falle, el usuario vea un error claro (no silencioso).
- (Opcional pero recomendado) Hacer que se vean correctamente los participantes de un chat/grupo (nombres/contador), evitando problemas de RLS recursiva.

Lo que ya sabemos (por inspección)
- El “buscar por email” funciona (tu respuesta: “Se encuentra pero no se crea”).
- En la base de datos no existe ningún chat creado (chats_count = 0), así que la creación no está llegando a persistirse o se aborta antes de insertar.
- RLS está habilitado en chats/chat_participants/messages y las políticas actuales de INSERT parecen correctas.
- La función `add_chat_participant(...)` hoy “devuelve false” en algunos casos sin lanzar error; en frontend no se comprueba ese booleano, por lo que puede fallar silenciosamente.
- En frontend, si `createChat(...)` devuelve null, el diálogo no muestra ningún toast de error (simplemente “no pasa nada”).

Hipótesis más probable del fallo
- La creación de chat se corta en `useChats.createChat()` porque:
  1) El `insert(...).select().single()` puede no devolver fila (o devolver error) y entonces se considera “fallo” y no se continúa.
  2) O bien se crea el chat pero la lógica de añadir participantes falla silenciosamente (RPC devuelve false) y el chat no aparece porque el usuario no queda como participante.
- En ambos casos el usuario no ve un error, por eso parece que “no crea”.

Estrategia de solución (robusta)
- Mover la creación a una única operación en backend (una función SQL “create_chat”) que:
  - Inserta el chat.
  - Inserta todos los participantes (incluido el creador).
  - Devuelve el `chat_id`.
  - Si algo no está permitido o falta información, lanza un error (no “false” silencioso).
- En frontend, cambiar `useChats.createChat()` para llamar a esa función y mostrar toasts con el error real si falla.

Cambios propuestos (Backend / Base de datos)
1) Nueva función backend: `public.create_chat(p_participant_ids uuid[], p_is_group boolean, p_group_name text)`
   - SECURITY DEFINER, con `SET search_path = public`.
   - Validaciones:
     - Requerir usuario autenticado (`auth.uid()` no null).
     - Normalizar y deduplicar participantes.
     - Añadir siempre al creador (`auth.uid()`).
     - Si `p_is_group = true`:
       - Requerir `p_group_name` no vacío.
       - Requerir al menos 1 participante además del creador.
     - Si `p_is_group = false`:
       - Requerir exactamente 1 participante además del creador (chat 1-1).
     - Verificar que todos los `user_id` existen en `public.profiles` (evitar ids inválidos).
   - Insertar en `public.chats` con `created_by = auth.uid()`.
   - Insertar en `public.chat_participants` todos los usuarios (ON CONFLICT DO NOTHING).
   - Retornar `chat_id` (uuid).
   - En caso de no autorización / validación fallida: `RAISE EXCEPTION` con mensaje claro.

2) (Recomendado) Endurecer permisos de funciones (seguridad + evitar uso anónimo)
   - Revocar EXECUTE de PUBLIC en `find_user_by_email`, `add_chat_participant` y la nueva `create_chat`.
   - Conceder EXECUTE solo a `authenticated`.
   - Esto además reduce superficies raras de comportamiento (y mejora la postura de privacidad).

3) (Opcional pero recomendado para UX) Arreglar visibilidad de participantes sin caer en “infinite recursion”
   - Ahora mismo la policy SELECT de `chat_participants` solo deja ver “mis filas”, lo que impide cargar todos los participantes del chat (por eso contadores/nombres pueden estar mal).
   - Solución segura:
     - Crear función SECURITY DEFINER `public.is_chat_member(p_chat_id uuid, p_user_id uuid) returns boolean` que compruebe membership consultando `chat_participants` como owner (evita que una policy de `chat_participants` se autorefiera y cause recursión).
     - Cambiar policy SELECT en `chat_participants` a: “puedes ver filas si eres miembro del chat” usando `public.is_chat_member(chat_id, auth.uid())`.

Cambios propuestos (Frontend)
1) `src/hooks/useChats.tsx`
   - Reemplazar la implementación de `createChat(...)` para que llame a `supabase.rpc('create_chat', { ... })` (o el nombre que definamos).
   - Manejar errores y devolver null si falla.
   - Importante: si el RPC devuelve un error o un resultado inesperado, mostrarlo (console + toast).

2) `src/components/chat/NewChatDialogNew.tsx`
   - Si `onCreateChat(...)` devuelve null:
     - Mostrar `toast.error('No se pudo crear el grupo. ...')` con un texto amigable.
   - Mientras `loading=true`, desactivar botones y evitar dobles envíos (ya se hace parcialmente, lo reforzamos).

3) (Pequeña mejora de diagnóstico)
   - Loguear en consola (solo en desarrollo) el error completo devuelto por el backend (message, code).
   - Esto nos permitirá, si aún falla, ver el motivo exacto sin “adivinar”.

Plan de pruebas (manual)
- En preview:
  1) Abrir “Nuevo grupo”.
  2) Buscar 1–2 usuarios por email (que existan) y añadirlos.
  3) Escribir nombre del grupo.
  4) Pulsar “Crear grupo”.
  5) Verificar:
     - Se cierra el diálogo.
     - Aparece el chat en la lista inmediatamente.
     - Al entrar al chat, el header muestra el nombre del grupo.
- Si algo falla:
  - Debe aparecer un toast con el motivo (por ejemplo: “necesitas nombre”, “usuario no autenticado”, “participante inválido”, etc).

Riesgos / consideraciones
- Este cambio centraliza la lógica de creación en backend (mejor para consistencia), pero requiere una migración SQL.
- Ajustar policies de `chat_participants` para ver todos los miembros es una decisión de privacidad. Se limita a “solo miembros del chat”, así que es razonable para una app de mensajería.

Entregables
- 1 migración SQL con: creación de función `create_chat`, (opcional) `is_chat_member`, ajustes de grants/policies.
- Cambios en `useChats.tsx` y `NewChatDialogNew.tsx` para usar el RPC y mostrar errores.
