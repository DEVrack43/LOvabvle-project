// Service Worker for Push Notifications with inline reply

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// Handle push notifications
self.addEventListener('push', (event) => {
  if (!event.data) return;

  const data = event.data.json();
  const { title, body, icon, tag, chatId, senderId, type } = data;

  const options = {
    body,
    icon: icon || '/favicon.ico',
    badge: '/favicon.ico',
    tag: tag || 'default',
    renotify: true,
    requireInteraction: type === 'call',
    vibrate: [200, 100, 200],
    data: { chatId, senderId, type },
    actions: [],
  };

  // Add reply action for messages
  if (type === 'message') {
    options.actions = [
      { action: 'reply', title: 'Responder', type: 'text', placeholder: 'Escribe tu respuesta...' },
      { action: 'open', title: 'Abrir' },
    ];
  } else if (type === 'story') {
    options.actions = [
      { action: 'open', title: 'Ver estado' },
    ];
  } else if (type === 'call') {
    options.actions = [
      { action: 'open', title: 'Contestar' },
    ];
  }

  event.waitUntil(self.registration.showNotification(title, options));
});

// Handle notification click
self.addEventListener('notificationclick', (event) => {
  const { action, notification } = event;
  const { chatId, type } = notification.data || {};

  notification.close();

  if (action === 'reply') {
    // Get the reply text from the notification
    const replyText = event.reply;
    if (replyText && chatId) {
      // Send reply via edge function
      event.waitUntil(sendReply(chatId, replyText));
    }
    return;
  }

  // Open or focus the app
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
      // Try to focus an existing window
      for (const client of clients) {
        if (client.url.includes(self.location.origin)) {
          client.focus();
          if (chatId) {
            client.postMessage({ type: 'OPEN_CHAT', chatId });
          }
          return;
        }
      }
      // Open a new window
      return self.clients.openWindow('/');
    })
  );
});

async function sendReply(chatId, content) {
  try {
    // Get the Supabase URL and key from a cached config
    const cache = await caches.open('app-config');
    const configResponse = await cache.match('config');
    if (!configResponse) return;

    const config = await configResponse.json();
    const { supabaseUrl, supabaseKey, userId } = config;

    // Send message directly via Supabase REST API
    const response = await fetch(`${supabaseUrl}/rest/v1/messages`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': supabaseKey,
        'Authorization': `Bearer ${config.accessToken}`,
        'Prefer': 'return=minimal',
      },
      body: JSON.stringify({
        chat_id: chatId,
        sender_id: userId,
        content: content,
        type: 'text',
        status: 'sent',
      }),
    });

    if (!response.ok) {
      console.error('SW: Failed to send reply:', response.status);
    }
  } catch (error) {
    console.error('SW: Error sending reply:', error);
  }
}
