
-- Fix: the tables were already created, just remove the failed realtime line
-- Nothing to do, tables created successfully before the error
SELECT 1;
