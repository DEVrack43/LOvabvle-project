-- Fix: Remove overly permissive policy that exposes emails to all authenticated users
DROP POLICY IF EXISTS "Authenticated users can view profiles for chat" ON public.profiles;

-- Create a secure RPC function for user lookup that doesn't expose email
-- Returns only non-sensitive profile data (id, display_name, avatar_url)
CREATE OR REPLACE FUNCTION public.find_user_by_email(lookup_email TEXT)
RETURNS TABLE(id UUID, display_name TEXT, avatar_url TEXT)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.display_name, p.avatar_url
  FROM public.profiles p
  WHERE p.email = lower(lookup_email)
  LIMIT 1;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.find_user_by_email(TEXT) TO authenticated;