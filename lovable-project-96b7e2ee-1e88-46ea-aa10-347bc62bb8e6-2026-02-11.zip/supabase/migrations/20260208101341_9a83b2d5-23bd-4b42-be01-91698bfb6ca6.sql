-- Recreate the profiles_public view with security_invoker = false
-- so it bypasses RLS on profiles table and shows basic info (no email) for all users
DROP VIEW IF EXISTS public.profiles_public;

CREATE VIEW public.profiles_public
WITH (security_invoker = false)
AS
SELECT id, display_name, avatar_url, created_at, updated_at
FROM public.profiles;