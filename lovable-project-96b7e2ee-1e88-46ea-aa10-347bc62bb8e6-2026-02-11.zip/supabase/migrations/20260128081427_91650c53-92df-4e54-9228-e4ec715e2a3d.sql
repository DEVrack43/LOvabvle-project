-- 1. Helper function to check chat membership (avoids RLS recursion)
CREATE OR REPLACE FUNCTION public.is_chat_member(p_chat_id uuid, p_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.chat_participants
    WHERE chat_id = p_chat_id
      AND user_id = p_user_id
  )
$$;

-- 2. Main function to create chat with participants atomically
CREATE OR REPLACE FUNCTION public.create_chat(
  p_participant_ids uuid[],
  p_is_group boolean,
  p_group_name text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_creator_id uuid;
  v_chat_id uuid;
  v_all_participants uuid[];
  v_participant_id uuid;
  v_invalid_count int;
BEGIN
  -- Get authenticated user
  v_creator_id := auth.uid();
  IF v_creator_id IS NULL THEN
    RAISE EXCEPTION 'Usuario no autenticado';
  END IF;

  -- Build participant list: deduplicate and always include creator
  v_all_participants := array_agg(DISTINCT x) FROM unnest(p_participant_ids || v_creator_id) AS x;

  -- Validate based on chat type
  IF p_is_group THEN
    -- Group chat validations
    IF p_group_name IS NULL OR trim(p_group_name) = '' THEN
      RAISE EXCEPTION 'El grupo necesita un nombre';
    END IF;
    IF array_length(v_all_participants, 1) < 2 THEN
      RAISE EXCEPTION 'El grupo necesita al menos un participante además de ti';
    END IF;
  ELSE
    -- 1-1 chat validations
    IF array_length(v_all_participants, 1) != 2 THEN
      RAISE EXCEPTION 'Un chat individual requiere exactamente un participante';
    END IF;
  END IF;

  -- Verify all participant IDs exist in profiles
  SELECT COUNT(*) INTO v_invalid_count
  FROM unnest(v_all_participants) AS pid
  WHERE NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = pid);
  
  IF v_invalid_count > 0 THEN
    RAISE EXCEPTION 'Uno o más participantes no existen';
  END IF;

  -- Create the chat
  INSERT INTO public.chats (is_group, group_name, created_by)
  VALUES (p_is_group, NULLIF(trim(p_group_name), ''), v_creator_id)
  RETURNING id INTO v_chat_id;

  -- Add all participants
  FOREACH v_participant_id IN ARRAY v_all_participants
  LOOP
    INSERT INTO public.chat_participants (chat_id, user_id)
    VALUES (v_chat_id, v_participant_id)
    ON CONFLICT DO NOTHING;
  END LOOP;

  RETURN v_chat_id;
END;
$$;

-- 3. Update RLS policy on chat_participants to allow members to see all participants
DROP POLICY IF EXISTS "Users can view their participations" ON public.chat_participants;

CREATE POLICY "Users can view chat participants"
ON public.chat_participants
FOR SELECT
USING (public.is_chat_member(chat_id, auth.uid()));

-- 4. Harden function permissions (revoke from PUBLIC, grant to authenticated only)
REVOKE EXECUTE ON FUNCTION public.find_user_by_email(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.find_user_by_email(text) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.add_chat_participant(uuid, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.add_chat_participant(uuid, uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.create_chat(uuid[], boolean, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.create_chat(uuid[], boolean, text) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.is_chat_member(uuid, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_chat_member(uuid, uuid) TO authenticated;