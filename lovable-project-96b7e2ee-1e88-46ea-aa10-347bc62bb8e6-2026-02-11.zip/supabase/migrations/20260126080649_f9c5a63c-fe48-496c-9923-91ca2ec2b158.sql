-- Drop the existing restrictive policy
DROP POLICY IF EXISTS "Users can create chats" ON public.chats;

-- Create a new permissive policy for creating chats
CREATE POLICY "Users can create chats" ON public.chats
  FOR INSERT
  WITH CHECK (auth.uid() = created_by);