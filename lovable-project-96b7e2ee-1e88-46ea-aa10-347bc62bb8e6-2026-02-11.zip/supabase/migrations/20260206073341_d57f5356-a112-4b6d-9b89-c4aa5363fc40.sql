-- Create a function to check if two users share a chat
CREATE OR REPLACE FUNCTION public.users_share_chat(user_a uuid, user_b uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.chat_participants cp1
    INNER JOIN public.chat_participants cp2 ON cp1.chat_id = cp2.chat_id
    WHERE cp1.user_id = user_a
      AND cp2.user_id = user_b
      AND cp1.user_id != cp2.user_id
  )
$$;

-- Drop the existing policy
DROP POLICY IF EXISTS "Users can view all stories" ON public.stories;

-- Create new policy that only allows viewing stories from contacts (users who share a chat)
CREATE POLICY "Users can view stories from contacts"
ON public.stories
FOR SELECT
USING (
  expires_at > now() AND (
    user_id = auth.uid() OR 
    public.users_share_chat(auth.uid(), user_id)
  )
);