-- Fix: Change the chats INSERT policy from RESTRICTIVE to PERMISSIVE
-- The current RESTRICTIVE policy blocks all inserts because there's no PERMISSIVE policy

-- Drop the current restrictive policy
DROP POLICY IF EXISTS "Users can create chats" ON public.chats;

-- Create a PERMISSIVE policy that allows authenticated users to create chats
CREATE POLICY "Users can create chats" ON public.chats
  FOR INSERT
  WITH CHECK (auth.uid() = created_by);

-- Also fix chat_participants - same issue
DROP POLICY IF EXISTS "Users can join chats" ON public.chat_participants;

CREATE POLICY "Users can join chats" ON public.chat_participants
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Fix messages insert policy too
DROP POLICY IF EXISTS "Users can send messages to their chats" ON public.messages;

CREATE POLICY "Users can send messages to their chats" ON public.messages
  FOR INSERT
  WITH CHECK (
    auth.uid() = sender_id AND
    EXISTS (
      SELECT 1 FROM chat_participants
      WHERE chat_participants.chat_id = messages.chat_id
      AND chat_participants.user_id = auth.uid()
    )
  );