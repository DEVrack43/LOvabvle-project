-- Allow group creators and members to update group chats
CREATE POLICY "Users can update their group chats"
ON public.chats
FOR UPDATE
USING (
  is_group = true AND 
  EXISTS (
    SELECT 1 FROM public.chat_participants 
    WHERE chat_id = id AND user_id = auth.uid()
  )
)
WITH CHECK (
  is_group = true AND 
  EXISTS (
    SELECT 1 FROM public.chat_participants 
    WHERE chat_id = id AND user_id = auth.uid()
  )
);