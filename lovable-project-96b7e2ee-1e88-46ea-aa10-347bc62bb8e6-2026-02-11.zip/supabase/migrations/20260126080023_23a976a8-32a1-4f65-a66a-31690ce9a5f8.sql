-- Fix: Create a function to add participants to chats (for group creation)
-- This allows the chat creator to add other participants securely

CREATE OR REPLACE FUNCTION public.add_chat_participant(p_chat_id UUID, p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_creator_id UUID;
  v_is_creator BOOLEAN;
BEGIN
  -- Get the chat creator
  SELECT created_by INTO v_creator_id FROM public.chats WHERE id = p_chat_id;
  
  -- Check if current user is the creator of this chat
  v_is_creator := (v_creator_id = auth.uid());
  
  -- Only allow if:
  -- 1. User is adding themselves, OR
  -- 2. User is the creator of the chat (for adding others to group)
  IF p_user_id = auth.uid() OR v_is_creator THEN
    INSERT INTO public.chat_participants (chat_id, user_id)
    VALUES (p_chat_id, p_user_id)
    ON CONFLICT DO NOTHING;
    RETURN TRUE;
  END IF;
  
  RETURN FALSE;
END;
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION public.add_chat_participant(UUID, UUID) TO authenticated;