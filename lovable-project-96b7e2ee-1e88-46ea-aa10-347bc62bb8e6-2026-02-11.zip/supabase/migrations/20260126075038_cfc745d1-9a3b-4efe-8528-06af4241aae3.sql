-- Fix: Allow chat participants to view shared files (not just the uploader)
-- Drop the current restrictive policy
DROP POLICY IF EXISTS "Users can view their own files" ON storage.objects;

-- Create a new policy that allows:
-- 1. Users to view their own uploaded files
-- 2. Chat participants to view files shared in chats they're part of
CREATE POLICY "Chat participants can view shared files" ON storage.objects
  FOR SELECT
  USING (
    bucket_id = 'chat-files' AND (
      -- Allow access to own files (user's folder)
      auth.uid()::text = (storage.foldername(name))[1]
      OR
      -- Allow access if user is in a chat where this file was shared
      EXISTS (
        SELECT 1 FROM public.messages m
        JOIN public.chat_participants cp ON cp.chat_id = m.chat_id
        WHERE m.file_url = name
        AND cp.user_id = auth.uid()
      )
    )
  );