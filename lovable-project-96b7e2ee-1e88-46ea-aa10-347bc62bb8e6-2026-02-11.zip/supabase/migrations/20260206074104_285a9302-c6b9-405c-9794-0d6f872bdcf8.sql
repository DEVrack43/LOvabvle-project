-- Create table for contact customizations (nicknames and custom avatars)
CREATE TABLE public.contact_overrides (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  contact_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  custom_name TEXT,
  custom_avatar TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, contact_id)
);

-- Enable RLS
ALTER TABLE public.contact_overrides ENABLE ROW LEVEL SECURITY;

-- Users can only view their own overrides
CREATE POLICY "Users can view own contact overrides"
ON public.contact_overrides
FOR SELECT
USING (auth.uid() = user_id);

-- Users can insert their own overrides
CREATE POLICY "Users can create own contact overrides"
ON public.contact_overrides
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Users can update their own overrides
CREATE POLICY "Users can update own contact overrides"
ON public.contact_overrides
FOR UPDATE
USING (auth.uid() = user_id);

-- Users can delete their own overrides
CREATE POLICY "Users can delete own contact overrides"
ON public.contact_overrides
FOR DELETE
USING (auth.uid() = user_id);

-- Add trigger for updated_at
CREATE TRIGGER update_contact_overrides_updated_at
BEFORE UPDATE ON public.contact_overrides
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();