-- Allow authenticated users to upload group avatars
CREATE POLICY "Users can upload group avatars"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'avatars' AND 
  auth.role() = 'authenticated' AND
  (storage.foldername(name))[1] = 'groups'
);

-- Allow authenticated users to update group avatars
CREATE POLICY "Users can update group avatars"
ON storage.objects
FOR UPDATE
USING (
  bucket_id = 'avatars' AND 
  auth.role() = 'authenticated' AND
  (storage.foldername(name))[1] = 'groups'
);

-- Allow authenticated users to upload contact override avatars
CREATE POLICY "Users can upload contact override avatars"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'avatars' AND 
  auth.role() = 'authenticated' AND
  (storage.foldername(name))[1] = 'contact-overrides' AND
  (storage.foldername(name))[2] = auth.uid()::text
);

-- Allow authenticated users to update their contact override avatars
CREATE POLICY "Users can update contact override avatars"
ON storage.objects
FOR UPDATE
USING (
  bucket_id = 'avatars' AND 
  auth.role() = 'authenticated' AND
  (storage.foldername(name))[1] = 'contact-overrides' AND
  (storage.foldername(name))[2] = auth.uid()::text
);

-- Allow public read access to group avatars and contact overrides in avatars bucket
CREATE POLICY "Public can read group and contact override avatars"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'avatars' AND 
  ((storage.foldername(name))[1] = 'groups' OR (storage.foldername(name))[1] = 'contact-overrides')
);