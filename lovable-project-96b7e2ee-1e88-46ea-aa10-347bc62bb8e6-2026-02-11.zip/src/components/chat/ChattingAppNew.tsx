import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Profile, ChatWithParticipants } from '@/types/database';
import { useAuth } from '@/hooks/useAuth';
import { useChats } from '@/hooks/useChats';
import { usePresence } from '@/hooks/usePresence';
import { useStories, UserStories } from '@/hooks/useStories';
import { useWebRTC } from '@/hooks/useWebRTC';
import { useNotifications } from '@/hooks/useNotifications';
import { useContactOverrides } from '@/hooks/useContactOverrides';
import { ChatSidebarNew } from './ChatSidebarNew';
import { ChatViewNew } from './ChatViewNew';
import { EmptyChat } from './EmptyChat';
import { NewChatDialogNew } from './NewChatDialogNew';
import { ProfileDialog } from './ProfileDialog';
import { VideoCallDialog } from './VideoCallDialog';
import { IncomingCallDialog } from './IncomingCallDialog';
import { StoryViewer } from './StoryViewer';
import { GroupSettingsDialog } from './GroupSettingsDialog';
import { ContactSettingsDialog } from './ContactSettingsDialog';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export const ChattingAppNew = () => {
  const { user, profile, signOut } = useAuth();
  const { chats, sendMessage, createChat, findUserByEmail, deleteChat, refetch } = useChats();
  const { presenceMap, fetchPresence, getPresence, isOnline } = usePresence();
  const { userStories, viewStory, deleteStory } = useStories();
  const webrtc = useWebRTC();
  const notifications = useNotifications();
  const contactOverrides = useContactOverrides();

  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [isNewChatOpen, setIsNewChatOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isGroupSettingsOpen, setIsGroupSettingsOpen] = useState(false);
  const [isContactSettingsOpen, setIsContactSettingsOpen] = useState(false);
  const [viewingStories, setViewingStories] = useState<UserStories | null>(null);
  const [activeCall, setActiveCall] = useState<{
    isOpen: boolean;
    userName: string;
    userAvatar: string;
    isVideo: boolean;
    calleeId: string;
  } | null>(null);

  const selectedChat = chats.find((chat) => chat.id === selectedChatId);
  
  // Get the other user in the selected chat for contact settings
  const selectedContactUser = selectedChat && !selectedChat.is_group
    ? selectedChat.participants.find((p) => p.id !== user?.id)
    : null;

  // Request notification permission on mount
  useEffect(() => {
    const requestNotifications = async () => {
      const granted = await notifications.requestPermission();
      if (granted) {
        toast.success('Notificaciones activadas');
      }
    };
    requestNotifications();
  }, []);

  // Listen for SW open-chat events (from notification click)
  useEffect(() => {
    const handler = (e: Event) => {
      const chatId = (e as CustomEvent).detail?.chatId;
      if (chatId) setSelectedChatId(chatId);
    };
    window.addEventListener('sw-open-chat', handler);
    return () => window.removeEventListener('sw-open-chat', handler);
  }, []);

  // Listen for new messages and show notifications
  useEffect(() => {
    if (!user || chats.length === 0) return;

    const allMessages = chats.flatMap((c) => 
      c.messages.map((m) => ({ ...m, chatId: c.id, chat: c }))
    );
    
    if (allMessages.length === 0) return;

    const latestMessage = allMessages.reduce((latest, msg) => 
      new Date(msg.created_at) > new Date(latest.created_at) ? msg : latest
    );

    const messageAge = Date.now() - new Date(latestMessage.created_at).getTime();
    if (messageAge < 5000 && latestMessage.sender_id !== user.id) {
      const sender = latestMessage.chat.participants.find(
        (p) => p.id === latestMessage.sender_id
      );
      const senderName = sender?.display_name || 'Alguien';
      const preview = latestMessage.content || 
        (latestMessage.type === 'image' ? '📷 Imagen' : 
         latestMessage.type === 'audio' ? '🎤 Audio' : '📎 Archivo');
      
      // Get other participant IDs for push notifications (exclude sender)
      const recipientIds = latestMessage.chat.participants
        .filter(p => p.id !== latestMessage.sender_id)
        .map(p => p.id);
      
      notifications.notifyNewMessage(
        senderName, 
        preview, 
        sender?.avatar_url || undefined,
        latestMessage.chatId,
        latestMessage.sender_id,
        recipientIds
      );
    }
  }, [chats, user, notifications]);

  // Listen for new stories and notify contacts
  useEffect(() => {
    if (!user || !userStories.length) return;

    const channel = supabase
      .channel('story-notifications')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'stories' },
        (payload) => {
          const newStory = payload.new as any;
          // Don't notify about own stories
          if (newStory.user_id === user.id) return;

          // Find the story author from participants
          const allParticipants = chats.flatMap(c => c.participants);
          const author = allParticipants.find(p => p.id === newStory.user_id);
          if (!author) return;

          // Get IDs of users who share a chat with the author
          const contactIds = chats
            .filter(c => c.participants.some(p => p.id === newStory.user_id))
            .flatMap(c => c.participants.map(p => p.id))
            .filter(id => id !== newStory.user_id);
          const uniqueContactIds = [...new Set(contactIds)];

          notifications.notifyNewStory(
            author.display_name || 'Alguien',
            author.avatar_url || undefined,
            uniqueContactIds
          );
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, chats, notifications, userStories]);

  // Notify on incoming calls
  useEffect(() => {
    if (webrtc.incomingCall) {
      notifications.notifyIncomingCall(
        webrtc.incomingCall.callerName,
        webrtc.incomingCall.isVideo,
        webrtc.incomingCall.callerAvatar
      );
    }
  }, [webrtc.incomingCall, notifications]);

  // Fetch presence for all chat participants
  const allParticipantIds = chats.flatMap((c) => c.participants.map((p) => p.id));
  if (allParticipantIds.length > 0 && presenceMap.size === 0) {
    fetchPresence([...new Set(allParticipantIds)]);
  }

  const handleSendMessage = (content: string) => {
    if (selectedChatId) {
      sendMessage(selectedChatId, content, 'text');
    }
  };

  const handleSendFile = (url: string, name: string, type: 'file' | 'image') => {
    if (selectedChatId) {
      sendMessage(selectedChatId, null, type, url, name);
    }
  };

  const handleSendAudio = (url: string, name: string) => {
    if (selectedChatId) {
      sendMessage(selectedChatId, null, 'audio', url, name);
    }
  };

  const handleCreateChat = async (userIds: string[], isGroup: boolean, groupName?: string) => {
    const chatId = await createChat(userIds, isGroup, groupName);
    if (chatId) {
      setSelectedChatId(chatId);
    }
    return chatId;
  };

  const handleVideoCall = () => {
    if (!selectedChat || !user) return;
    const otherUser = selectedChat.participants.find((p) => p.id !== user.id);
    if (otherUser) {
      setActiveCall({
        isOpen: true,
        userName: otherUser.display_name || otherUser.email || 'Usuario',
        userAvatar: otherUser.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${otherUser.email}`,
        isVideo: true,
        calleeId: otherUser.id,
      });
      webrtc.startCall(otherUser.id, true);
    }
  };

  const handleVoiceCall = () => {
    if (!selectedChat || !user) return;
    const otherUser = selectedChat.participants.find((p) => p.id !== user.id);
    if (otherUser) {
      setActiveCall({
        isOpen: true,
        userName: otherUser.display_name || otherUser.email || 'Usuario',
        userAvatar: otherUser.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${otherUser.email}`,
        isVideo: false,
        calleeId: otherUser.id,
      });
      webrtc.startCall(otherUser.id, false);
    }
  };

  const handleDeleteChat = async (chatId: string) => {
    await deleteChat(chatId);
    if (selectedChatId === chatId) {
      setSelectedChatId(null);
    }
  };

  const handleAcceptIncomingCall = async () => {
    if (!webrtc.incomingCall) return;
    const { callId, callerId, callerName, callerAvatar, isVideo, offerSdp } = webrtc.incomingCall;
    setActiveCall({
      isOpen: true,
      userName: callerName,
      userAvatar: callerAvatar,
      isVideo,
      calleeId: callerId,
    });
    await webrtc.answerCall(callId, callerId, isVideo, offerSdp);
  };

  const handleEndCall = () => {
    webrtc.endCall();
    setActiveCall(null);
  };

  if (!profile || !user) return null;

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      {/* Sidebar */}
      <div
        className={cn(
          'h-full w-full shrink-0 border-r md:w-[380px]',
          selectedChatId && 'hidden md:block'
        )}
      >
        <ChatSidebarNew
          chats={chats}
          currentUser={profile}
          selectedChatId={selectedChatId}
          onSelectChat={setSelectedChatId}
          onNewChat={() => setIsNewChatOpen(true)}
          onDeleteChat={handleDeleteChat}
          onSignOut={signOut}
          onEditProfile={() => setIsProfileOpen(true)}
          getPresence={getPresence}
          userStories={userStories}
          onViewStory={setViewingStories}
          getDisplayName={contactOverrides.getDisplayName}
          getDisplayAvatar={contactOverrides.getDisplayAvatar}
        />
      </div>

      {/* Chat Area */}
      <div
        className={cn(
          'flex-1',
          !selectedChatId && 'hidden md:block'
        )}
      >
        {selectedChat ? (
          <ChatViewNew
            chat={selectedChat}
            currentUserId={user.id}
            onSendMessage={handleSendMessage}
            onSendFile={handleSendFile}
            onSendAudio={handleSendAudio}
            onVideoCall={handleVideoCall}
            onVoiceCall={handleVoiceCall}
            onBack={() => setSelectedChatId(null)}
            getPresence={getPresence}
            onEditGroup={selectedChat.is_group ? () => setIsGroupSettingsOpen(true) : undefined}
            onEditContact={!selectedChat.is_group ? () => setIsContactSettingsOpen(true) : undefined}
            getDisplayName={contactOverrides.getDisplayName}
            getDisplayAvatar={contactOverrides.getDisplayAvatar}
          />
        ) : (
          <EmptyChat />
        )}
      </div>

      {/* Dialogs */}
      <NewChatDialogNew
        open={isNewChatOpen}
        onOpenChange={setIsNewChatOpen}
        onFindUser={findUserByEmail}
        onCreateChat={handleCreateChat}
      />

      <ProfileDialog
        open={isProfileOpen}
        onOpenChange={setIsProfileOpen}
      />

      {/* Group Settings Dialog */}
      {selectedChat?.is_group && (
        <GroupSettingsDialog
          open={isGroupSettingsOpen}
          onOpenChange={setIsGroupSettingsOpen}
          chat={selectedChat}
          onUpdate={refetch}
        />
      )}

      {/* Contact Settings Dialog */}
      {selectedContactUser && (
        <ContactSettingsDialog
          open={isContactSettingsOpen}
          onOpenChange={setIsContactSettingsOpen}
          contact={selectedContactUser}
          currentOverride={contactOverrides.getOverride(selectedContactUser.id)}
          onSave={(name, avatar) => contactOverrides.setOverride(selectedContactUser.id, name, avatar)}
          onReset={() => contactOverrides.removeOverride(selectedContactUser.id)}
        />
      )}

      {/* Video/Voice Call Dialog */}
      {activeCall && (
        <VideoCallDialog
          open={activeCall.isOpen}
          onOpenChange={(open) => {
            if (!open) handleEndCall();
          }}
          userName={activeCall.userName}
          userAvatar={activeCall.userAvatar}
          isVideo={activeCall.isVideo}
          callState={webrtc.callState}
          localStream={webrtc.localStream}
          remoteStream={webrtc.remoteStream}
          onEndCall={handleEndCall}
          onToggleMute={webrtc.toggleMute}
          onToggleVideo={webrtc.toggleVideo}
          setLocalVideoRef={webrtc.setLocalVideoRef}
          setRemoteVideoRef={webrtc.setRemoteVideoRef}
        />
      )}

      {/* Incoming Call Dialog */}
      {webrtc.incomingCall && !activeCall && (
        <IncomingCallDialog
          open={true}
          callerName={webrtc.incomingCall.callerName}
          callerAvatar={webrtc.incomingCall.callerAvatar}
          isVideo={webrtc.incomingCall.isVideo}
          onAccept={handleAcceptIncomingCall}
          onReject={webrtc.rejectCall}
        />
      )}

      {/* Story Viewer */}
      <StoryViewer
        userStories={viewingStories}
        open={!!viewingStories}
        onOpenChange={(open) => !open && setViewingStories(null)}
        onViewStory={viewStory}
        onDeleteStory={deleteStory}
      />
    </div>
  );
};
