import { useState, useEffect } from 'react';
import { Phone, PhoneOff, Video, VideoOff, Mic, MicOff } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { User } from '@/types/chat';
import { cn } from '@/lib/utils';

interface CallDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: User | null;
  isVideo: boolean;
}

export const CallDialog = ({
  open,
  onOpenChange,
  user,
  isVideo,
}: CallDialogProps) => {
  const [callStatus, setCallStatus] = useState<'calling' | 'connected' | 'ended'>('calling');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(isVideo);
  const [callDuration, setCallDuration] = useState(0);

  useEffect(() => {
    if (open) {
      setCallStatus('calling');
      setCallDuration(0);
      
      // Simulate connection after 2 seconds
      const connectTimeout = setTimeout(() => {
        setCallStatus('connected');
      }, 2000);

      return () => clearTimeout(connectTimeout);
    }
  }, [open]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (callStatus === 'connected') {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callStatus]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEndCall = () => {
    setCallStatus('ended');
    setTimeout(() => onOpenChange(false), 500);
  };

  if (!user) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm overflow-hidden rounded-2xl border-0 bg-gradient-to-b from-primary/90 to-primary p-0">
        <div className="flex flex-col items-center px-8 py-12 text-primary-foreground">
          {/* Avatar */}
          <div className="relative">
            <img
              src={user.avatar}
              alt={user.name}
              className={cn(
                'h-28 w-28 rounded-full bg-card ring-4 ring-primary-foreground/20',
                callStatus === 'calling' && 'animate-pulse'
              )}
            />
            {callStatus === 'calling' && (
              <div className="absolute inset-0 animate-pulse-ring rounded-full bg-primary-foreground/30" />
            )}
          </div>

          {/* Name & Status */}
          <h2 className="mt-6 text-2xl font-semibold">{user.name}</h2>
          <p className="mt-2 text-primary-foreground/80">
            {callStatus === 'calling' && 'Llamando...'}
            {callStatus === 'connected' && (isVideo ? 'Videollamada' : 'Llamada de voz')}
            {callStatus === 'ended' && 'Llamada terminada'}
          </p>

          {/* Duration */}
          {callStatus === 'connected' && (
            <p className="mt-4 text-3xl font-light tabular-nums">
              {formatDuration(callDuration)}
            </p>
          )}

          {/* Controls */}
          <div className="mt-10 flex items-center gap-6">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMuted(!isMuted)}
              className={cn(
                'h-14 w-14 rounded-full',
                isMuted
                  ? 'bg-destructive hover:bg-destructive/90'
                  : 'bg-primary-foreground/20 hover:bg-primary-foreground/30'
              )}
            >
              {isMuted ? (
                <MicOff className="h-6 w-6" />
              ) : (
                <Mic className="h-6 w-6" />
              )}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={handleEndCall}
              className="h-16 w-16 rounded-full bg-destructive hover:bg-destructive/90"
            >
              <PhoneOff className="h-7 w-7" />
            </Button>

            {isVideo && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsVideoOn(!isVideoOn)}
                className={cn(
                  'h-14 w-14 rounded-full',
                  !isVideoOn
                    ? 'bg-destructive hover:bg-destructive/90'
                    : 'bg-primary-foreground/20 hover:bg-primary-foreground/30'
                )}
              >
                {isVideoOn ? (
                  <Video className="h-6 w-6" />
                ) : (
                  <VideoOff className="h-6 w-6" />
                )}
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
