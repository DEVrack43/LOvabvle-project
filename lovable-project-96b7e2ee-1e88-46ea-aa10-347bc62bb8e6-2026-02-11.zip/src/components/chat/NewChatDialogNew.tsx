import { useState } from 'react';
import { Search, Users, Mail } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Profile } from '@/types/database';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { z } from 'zod';

const emailSchema = z.string().email('Email inválido');

interface NewChatDialogNewProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onFindUser: (email: string) => Promise<Profile | null>;
  onCreateChat: (userIds: string[], isGroup: boolean, groupName?: string) => Promise<string | null>;
}

export const NewChatDialogNew = ({
  open,
  onOpenChange,
  onFindUser,
  onCreateChat,
}: NewChatDialogNewProps) => {
  const [email, setEmail] = useState('');
  const [isGroupMode, setIsGroupMode] = useState(false);
  const [foundUsers, setFoundUsers] = useState<Profile[]>([]);
  const [groupName, setGroupName] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    const validation = emailSchema.safeParse(email);
    if (!validation.success) {
      toast.error('Ingresa un email válido');
      return;
    }

    setLoading(true);
    try {
      const user = await onFindUser(email);
      if (user) {
        if (isGroupMode) {
          if (!foundUsers.some(u => u.id === user.id)) {
            setFoundUsers(prev => [...prev, user]);
          }
          setEmail('');
        } else {
          // Create chat directly
          try {
            const chatId = await onCreateChat([user.id], false);
            if (chatId) {
              resetDialog();
              onOpenChange(false);
            }
          } catch (err: any) {
            toast.error(err?.message || 'No se pudo crear el chat');
          }
        }
      } else {
        toast.error('No se encontró un usuario con ese email');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveUser = (userId: string) => {
    setFoundUsers(prev => prev.filter(u => u.id !== userId));
  };

  const handleCreateGroup = async () => {
    if (foundUsers.length === 0) {
      toast.error('Agrega al menos un participante');
      return;
    }
    if (!groupName.trim()) {
      toast.error('El grupo necesita un nombre');
      return;
    }

    setLoading(true);
    try {
      const chatId = await onCreateChat(
        foundUsers.map(u => u.id),
        true,
        groupName.trim()
      );
      if (chatId) {
        resetDialog();
        onOpenChange(false);
      }
    } catch (err: any) {
      toast.error(err?.message || 'No se pudo crear el grupo');
    } finally {
      setLoading(false);
    }
  };

  const resetDialog = () => {
    setEmail('');
    setIsGroupMode(false);
    setFoundUsers([]);
    setGroupName('');
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(isOpen) => {
        if (!isOpen) resetDialog();
        onOpenChange(isOpen);
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isGroupMode ? 'Nuevo grupo' : 'Nuevo chat'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {isGroupMode && (
            <Input
              placeholder="Nombre del grupo"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
            />
          )}

          <div className="flex gap-2">
            <div className="relative flex-1">
              <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Buscar por email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10"
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>
            <Button onClick={handleSearch} disabled={loading}>
              <Search className="h-4 w-4" />
            </Button>
          </div>

          {!isGroupMode && (
            <Button
              variant="ghost"
              className="w-full justify-start gap-3 text-primary"
              onClick={() => setIsGroupMode(true)}
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
                <Users className="h-5 w-5 text-primary-foreground" />
              </div>
              <span>Crear un grupo</span>
            </Button>
          )}

          {/* Found users for group */}
          {isGroupMode && foundUsers.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Participantes:</p>
              <div className="flex flex-wrap gap-2">
                {foundUsers.map((user) => (
                  <div
                    key={user.id}
                    className="flex items-center gap-2 rounded-full bg-accent px-3 py-1"
                  >
                    <img
                      src={user.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`}
                      alt={user.display_name || ''}
                      className="h-6 w-6 rounded-full"
                    />
                    <span className="text-sm">{user.display_name || user.email}</span>
                    <button
                      onClick={() => handleRemoveUser(user.id)}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {isGroupMode && foundUsers.length > 0 && (
            <Button
              onClick={handleCreateGroup}
              disabled={!groupName.trim() || loading}
              className="w-full"
            >
              Crear grupo ({foundUsers.length} participantes)
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
