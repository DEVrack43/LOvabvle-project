import { useState, useRef } from 'react';
import { Smile, Paperclip, Mic, Send, X, FileIcon, Square } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { useFileUpload } from '@/hooks/useFileUpload';

interface MessageInputNewProps {
  onSendMessage: (content: string) => void;
  onSendFile: (url: string, name: string, type: 'file' | 'image') => void;
  onSendAudio: (url: string, name: string) => void;
}

export const MessageInputNew = ({ onSendMessage, onSendFile, onSendAudio }: MessageInputNewProps) => {
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const { uploadFile, uploading } = useFileUpload();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (selectedFile) {
      const result = await uploadFile(selectedFile);
      if (result) {
        const isImage = selectedFile.type.startsWith('image/');
        onSendFile(result.url, result.name, isImage ? 'image' : 'file');
      }
      setSelectedFile(null);
      return;
    }

    if (message.trim()) {
      onSendMessage(message.trim());
      setMessage('');
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioFile = new File([audioBlob], `audio-${Date.now()}.webm`, { type: 'audio/webm' });
        
        const result = await uploadFile(audioFile);
        if (result) {
          onSendAudio(result.url, result.name);
        }

        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error accessing microphone:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const toggleRecording = () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="glass flex items-center gap-2 border-t px-4 py-2.5"
    >
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        onChange={handleFileSelect}
        accept="image/*,audio/*,.pdf,.doc,.docx,.txt"
      />
      
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className="shrink-0 text-muted-foreground hover:text-primary"
      >
        <Smile className="h-6 w-6" />
      </Button>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className="shrink-0 text-muted-foreground hover:text-primary"
        onClick={() => fileInputRef.current?.click()}
        disabled={uploading}
      >
        <Paperclip className="h-6 w-6" />
      </Button>
      
      <div className="relative flex-1">
        {selectedFile ? (
          <div className="flex items-center gap-2 rounded-full bg-muted px-4 py-2">
            <FileIcon className="h-4 w-4 text-primary" />
            <span className="truncate text-sm">{selectedFile.name}</span>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => setSelectedFile(null)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <Input
            placeholder="Escribe un mensaje"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="rounded-full border-0 bg-muted pr-4 focus-visible:ring-1 focus-visible:ring-primary"
            disabled={isRecording}
          />
        )}
      </div>
      
      {message.trim() || selectedFile ? (
        <Button
          type="submit"
          size="icon"
          className="shrink-0 rounded-full bg-primary hover:bg-primary/90"
          disabled={uploading}
        >
          <Send className="h-5 w-5" />
        </Button>
      ) : (
        <Button
          type="button"
          size="icon"
          onClick={toggleRecording}
          className={cn(
            'relative shrink-0 rounded-full',
            isRecording
              ? 'bg-destructive hover:bg-destructive/90'
              : 'bg-primary hover:bg-primary/90'
          )}
        >
          {isRecording && (
            <span className="absolute inset-0 animate-pulse-ring rounded-full bg-destructive" />
          )}
          {isRecording ? (
            <Square className="relative h-4 w-4" />
          ) : (
            <Mic className="relative h-5 w-5" />
          )}
        </Button>
      )}
    </form>
  );
};
