import { ChatWithParticipants } from '@/types/database';
import { ChatHeaderNew } from './ChatHeaderNew';
import { ChatMessagesNew } from './ChatMessagesNew';
import { MessageInputNew } from './MessageInputNew';

interface UserPresence {
  user_id: string;
  status: 'online' | 'offline' | 'away';
  last_seen: string;
}

interface ChatViewNewProps {
  chat: ChatWithParticipants;
  currentUserId: string;
  onSendMessage: (content: string) => void;
  onSendFile: (url: string, name: string, type: 'file' | 'image') => void;
  onSendAudio: (url: string, name: string) => void;
  onVideoCall: () => void;
  onVoiceCall: () => void;
  onBack?: () => void;
  getPresence?: (userId: string) => UserPresence | undefined;
  onEditGroup?: () => void;
  onEditContact?: () => void;
  getDisplayName?: (contactId: string, originalName: string | null) => string;
  getDisplayAvatar?: (contactId: string, originalAvatar: string | null) => string;
}

export const ChatViewNew = ({
  chat,
  currentUserId,
  onSendMessage,
  onSendFile,
  onSendAudio,
  onVideoCall,
  onVoiceCall,
  onBack,
  getPresence,
  onEditGroup,
  onEditContact,
  getDisplayName,
  getDisplayAvatar,
}: ChatViewNewProps) => {
  return (
    <div className="flex h-full flex-col animate-ios-slide-in">
      <ChatHeaderNew
        chat={chat}
        currentUserId={currentUserId}
        onVideoCall={onVideoCall}
        onVoiceCall={onVoiceCall}
        onBack={onBack}
        getPresence={getPresence}
        onEditGroup={onEditGroup}
        onEditContact={onEditContact}
        getDisplayName={getDisplayName}
        getDisplayAvatar={getDisplayAvatar}
      />
      <ChatMessagesNew 
        messages={chat.messages} 
        participants={chat.participants}
        currentUserId={currentUserId}
        isGroup={chat.is_group}
        getDisplayName={getDisplayName}
      />
      <MessageInputNew 
        onSendMessage={onSendMessage} 
        onSendFile={onSendFile}
        onSendAudio={onSendAudio}
      />
    </div>
  );
};
