import { Message } from '@/types/chat';
import { currentUser } from '@/data/mockData';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { Check, CheckCheck } from 'lucide-react';

interface MessageBubbleProps {
  message: Message;
  isLast: boolean;
}

export const MessageBubble = ({ message, isLast }: MessageBubbleProps) => {
  const isSent = message.senderId === currentUser.id;

  const getStatusIcon = () => {
    if (!isSent) return null;
    if (message.status === 'read') {
      return <CheckCheck className="h-4 w-4 text-primary" />;
    }
    if (message.status === 'delivered') {
      return <CheckCheck className="h-4 w-4 text-muted-foreground" />;
    }
    return <Check className="h-4 w-4 text-muted-foreground" />;
  };

  return (
    <div
      className={cn(
        'flex w-full animate-message-in',
        isSent ? 'justify-end' : 'justify-start'
      )}
      style={{ animationDelay: isLast ? '0ms' : '0ms' }}
    >
      <div
        className={cn(
          'relative max-w-[75%] rounded-2xl px-4 py-2 shadow-sm',
          isSent
            ? 'rounded-br-md bg-chat-bubble-sent'
            : 'rounded-bl-md bg-chat-bubble-received'
        )}
      >
        <p className="text-[15px] leading-relaxed">{message.content}</p>
        <div
          className={cn(
            'mt-1 flex items-center gap-1',
            isSent ? 'justify-end' : 'justify-start'
          )}
        >
          <span className="text-[11px] text-muted-foreground">
            {format(message.timestamp, 'HH:mm')}
          </span>
          {getStatusIcon()}
        </div>
      </div>
    </div>
  );
};
