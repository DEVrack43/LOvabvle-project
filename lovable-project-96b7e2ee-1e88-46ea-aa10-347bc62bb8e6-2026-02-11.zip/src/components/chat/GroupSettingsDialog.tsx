import { useState, useRef } from 'react';
import { Camera, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ChatWithParticipants } from '@/types/database';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface GroupSettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  chat: ChatWithParticipants;
  onUpdate: () => void;
}

export const GroupSettingsDialog = ({
  open,
  onOpenChange,
  chat,
  onUpdate,
}: GroupSettingsDialogProps) => {
  const [groupName, setGroupName] = useState(chat.group_name || '');
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(chat.group_avatar);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Solo se permiten imágenes');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error('La imagen no puede superar 5MB');
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const filePath = `groups/${chat.id}/avatar.${fileExt}`;

      // Upload to avatars bucket
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      const newUrl = `${data.publicUrl}?t=${Date.now()}`;
      setPreviewUrl(newUrl);

      // Update chat record
      const { error: updateError } = await supabase
        .from('chats')
        .update({ group_avatar: newUrl })
        .eq('id', chat.id);

      if (updateError) throw updateError;

      toast.success('Imagen de grupo actualizada');
      onUpdate();
    } catch (error) {
      console.error('Error uploading avatar:', error);
      toast.error('Error al subir la imagen');
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    if (!groupName.trim()) {
      toast.error('El nombre del grupo no puede estar vacío');
      return;
    }

    setSaving(true);
    try {
      const { error } = await supabase
        .from('chats')
        .update({ group_name: groupName.trim() })
        .eq('id', chat.id);

      if (error) throw error;

      toast.success('Nombre del grupo actualizado');
      onUpdate();
      onOpenChange(false);
    } catch (error) {
      console.error('Error updating group:', error);
      toast.error('Error al actualizar el grupo');
    } finally {
      setSaving(false);
    }
  };

  const avatarUrl = previewUrl || `https://api.dicebear.com/7.x/shapes/svg?seed=${chat.id}`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Configuración del grupo</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Avatar */}
          <div className="flex flex-col items-center gap-3">
            <div className="relative">
              <img
                src={avatarUrl}
                alt={groupName}
                className="h-24 w-24 rounded-full bg-muted object-cover"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="absolute bottom-0 right-0 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground hover:bg-primary/90"
              >
                {uploading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Camera className="h-4 w-4" />
                )}
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                className="hidden"
              />
            </div>
            <p className="text-sm text-muted-foreground">
              Toca el icono para cambiar la imagen
            </p>
          </div>

          {/* Group Name */}
          <div className="space-y-2">
            <Label htmlFor="groupName">Nombre del grupo</Label>
            <Input
              id="groupName"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="Nombre del grupo"
              maxLength={50}
            />
          </div>

          {/* Participants */}
          <div className="space-y-2">
            <Label>Participantes ({chat.participants.length})</Label>
            <div className="flex flex-wrap gap-2">
              {chat.participants.map((participant) => (
                <div
                  key={participant.id}
                  className="flex items-center gap-2 rounded-full bg-muted px-3 py-1"
                >
                  <img
                    src={participant.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${participant.id}`}
                    alt={participant.display_name || 'Usuario'}
                    className="h-6 w-6 rounded-full"
                  />
                  <span className="text-sm">
                    {participant.display_name || 'Usuario'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Guardar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
