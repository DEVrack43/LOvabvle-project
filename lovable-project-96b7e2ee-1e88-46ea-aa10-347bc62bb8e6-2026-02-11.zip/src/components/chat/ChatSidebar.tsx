import { useState } from 'react';
import { Search, Plus, MoreVertical } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Chat, User } from '@/types/chat';
import { currentUser } from '@/data/mockData';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';

interface ChatSidebarProps {
  chats: Chat[];
  selectedChatId: string | null;
  onSelectChat: (chatId: string) => void;
  onNewChat: () => void;
}

export const ChatSidebar = ({
  chats,
  selectedChatId,
  onSelectChat,
  onNewChat,
}: ChatSidebarProps) => {
  const [searchQuery, setSearchQuery] = useState('');

  const getChatName = (chat: Chat): string => {
    if (chat.isGroup && chat.groupName) return chat.groupName;
    const otherUser = chat.participants.find((p) => p.id !== currentUser.id);
    return otherUser?.name || 'Chat';
  };

  const getChatAvatar = (chat: Chat): string => {
    if (chat.isGroup && chat.groupAvatar) return chat.groupAvatar;
    const otherUser = chat.participants.find((p) => p.id !== currentUser.id);
    return otherUser?.avatar || '';
  };

  const getOtherUserStatus = (chat: Chat): User['status'] | undefined => {
    if (chat.isGroup) return undefined;
    const otherUser = chat.participants.find((p) => p.id !== currentUser.id);
    return otherUser?.status;
  };

  const filteredChats = chats.filter((chat) =>
    getChatName(chat).toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex h-full w-full flex-col bg-chat-sidebar">
      {/* Header */}
      <div className="flex items-center justify-between bg-chat-header px-4 py-3">
        <div className="flex items-center gap-3">
          <img
            src={currentUser.avatar}
            alt={currentUser.name}
            className="h-10 w-10 rounded-full bg-card"
          />
          <span className="text-lg font-semibold text-primary-foreground">
            Chatting
          </span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="text-primary-foreground hover:bg-primary/80"
            onClick={onNewChat}
          >
            <Plus className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-primary-foreground hover:bg-primary/80"
          >
            <MoreVertical className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Search */}
      <div className="px-3 py-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar o empezar un chat nuevo"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="border-0 bg-muted pl-10 focus-visible:ring-1 focus-visible:ring-primary"
          />
        </div>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        {filteredChats.map((chat) => {
          const status = getOtherUserStatus(chat);
          const lastMessage = chat.messages[chat.messages.length - 1];
          
          return (
            <button
              key={chat.id}
              onClick={() => onSelectChat(chat.id)}
              className={cn(
                'flex w-full items-center gap-3 px-4 py-3 transition-colors hover:bg-accent',
                selectedChatId === chat.id && 'bg-accent'
              )}
            >
              <div className="relative">
                <img
                  src={getChatAvatar(chat)}
                  alt={getChatName(chat)}
                  className="h-12 w-12 rounded-full bg-muted"
                />
                {status === 'online' && (
                  <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-chat-sidebar bg-online" />
                )}
              </div>
              <div className="flex-1 overflow-hidden text-left">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{getChatName(chat)}</span>
                  {lastMessage && (
                    <span className="text-xs text-muted-foreground">
                      {formatDistanceToNow(lastMessage.timestamp, {
                        addSuffix: false,
                        locale: es,
                      })}
                    </span>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <p className="truncate text-sm text-muted-foreground">
                    {lastMessage?.senderId === currentUser.id && (
                      <span className="mr-1">✓✓</span>
                    )}
                    {lastMessage?.content || 'Sin mensajes'}
                  </p>
                  {chat.unreadCount > 0 && (
                    <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1.5 text-xs font-medium text-primary-foreground">
                      {chat.unreadCount}
                    </span>
                  )}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
