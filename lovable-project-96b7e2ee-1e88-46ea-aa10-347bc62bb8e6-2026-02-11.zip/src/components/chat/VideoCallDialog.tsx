import { useState, useEffect, useRef } from 'react';
import { Phone, PhoneOff, Video, VideoOff, Mic, MicOff } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface VideoCallDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userName: string;
  userAvatar: string;
  isVideo: boolean;
  callState: 'idle' | 'calling' | 'ringing' | 'connected';
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  onEndCall: () => void;
  onToggleMute: () => boolean;
  onToggleVideo: () => boolean;
  setLocalVideoRef: (ref: HTMLVideoElement | null) => void;
  setRemoteVideoRef: (ref: HTMLVideoElement | null) => void;
}

export const VideoCallDialog = ({
  open,
  onOpenChange,
  userName,
  userAvatar,
  isVideo,
  callState,
  localStream,
  remoteStream,
  onEndCall,
  onToggleMute,
  onToggleVideo,
  setLocalVideoRef,
  setRemoteVideoRef,
}: VideoCallDialogProps) => {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (localVideoRef.current) {
      setLocalVideoRef(localVideoRef.current);
    }
    if (remoteVideoRef.current) {
      setRemoteVideoRef(remoteVideoRef.current);
    }
  }, [setLocalVideoRef, setRemoteVideoRef]);

  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream]);

  useEffect(() => {
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [remoteStream]);

  useEffect(() => {
    if (open) {
      setCallDuration(0);
      setIsMuted(false);
      setIsVideoOff(false);
    }
  }, [open]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (callState === 'connected') {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callState]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleEndCall = () => {
    onEndCall();
    onOpenChange(false);
  };

  const handleToggleMute = () => {
    const newMuted = onToggleMute();
    setIsMuted(newMuted);
  };

  const handleToggleVideo = () => {
    const newVideoOff = onToggleVideo();
    setIsVideoOff(newVideoOff);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="h-[90vh] max-w-3xl overflow-hidden border-0 bg-black p-0">
        <DialogTitle className="sr-only">{isVideo ? 'Videollamada' : 'Llamada de voz'} con {userName}</DialogTitle>
        <div className="relative flex h-full items-center justify-center">
          {isVideo && callState === 'connected' ? (
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex flex-col items-center gap-6 text-white">
              <img
                src={userAvatar}
                alt={userName}
                className={cn(
                  'h-32 w-32 rounded-full bg-card ring-4 ring-white/20',
                  callState === 'calling' && 'animate-pulse'
                )}
              />
              <h2 className="text-2xl font-semibold">{userName}</h2>
              <p className="text-white/70">
                {callState === 'calling' && 'Llamando...'}
                {callState === 'ringing' && 'Timbrando...'}
                {callState === 'connected' && (isVideo ? 'Videollamada' : 'Llamada de voz')}
              </p>
              {callState === 'connected' && (
                <p className="text-3xl font-light tabular-nums">
                  {formatDuration(callDuration)}
                </p>
              )}
            </div>
          )}

          {/* Local Video (PiP) */}
          {isVideo && callState === 'connected' && (
            <div className="absolute bottom-24 right-4 h-40 w-28 overflow-hidden rounded-lg bg-card shadow-lg">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className={cn(
                  'h-full w-full object-cover',
                  isVideoOff && 'hidden'
                )}
              />
              {isVideoOff && (
                <div className="flex h-full items-center justify-center bg-muted">
                  <VideoOff className="h-8 w-8 text-muted-foreground" />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="absolute bottom-0 left-0 right-0 flex items-center justify-center gap-6 bg-gradient-to-t from-black/80 to-transparent pb-8 pt-16">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleToggleMute}
            className={cn(
              'h-14 w-14 rounded-full text-white',
              isMuted ? 'bg-destructive hover:bg-destructive/90' : 'bg-white/20 hover:bg-white/30'
            )}
          >
            {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
          </Button>

          <Button
            variant="ghost"
            size="icon"
            onClick={handleEndCall}
            className="h-16 w-16 rounded-full bg-destructive hover:bg-destructive/90 text-white"
          >
            <PhoneOff className="h-7 w-7" />
          </Button>

          {isVideo && (
            <Button
              variant="ghost"
              size="icon"
              onClick={handleToggleVideo}
              className={cn(
                'h-14 w-14 rounded-full text-white',
                isVideoOff ? 'bg-destructive hover:bg-destructive/90' : 'bg-white/20 hover:bg-white/30'
              )}
            >
              {isVideoOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
