import { useState } from 'react';
import { Smile, Paperclip, Mic, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface MessageInputProps {
  onSendMessage: (content: string) => void;
}

export const MessageInput = ({ onSendMessage }: MessageInputProps) => {
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onSendMessage(message.trim());
      setMessage('');
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="flex items-center gap-2 border-t bg-card px-4 py-3"
    >
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className="shrink-0 text-muted-foreground hover:text-primary"
      >
        <Smile className="h-6 w-6" />
      </Button>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className="shrink-0 text-muted-foreground hover:text-primary"
      >
        <Paperclip className="h-6 w-6" />
      </Button>
      <div className="relative flex-1">
        <Input
          placeholder="Escribe un mensaje"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="rounded-full border-0 bg-muted pr-4 focus-visible:ring-1 focus-visible:ring-primary"
        />
      </div>
      {message.trim() ? (
        <Button
          type="submit"
          size="icon"
          className="shrink-0 rounded-full bg-primary hover:bg-primary/90"
        >
          <Send className="h-5 w-5" />
        </Button>
      ) : (
        <Button
          type="button"
          size="icon"
          onClick={toggleRecording}
          className={cn(
            'relative shrink-0 rounded-full',
            isRecording
              ? 'bg-destructive hover:bg-destructive/90'
              : 'bg-primary hover:bg-primary/90'
          )}
        >
          {isRecording && (
            <span className="absolute inset-0 animate-pulse-ring rounded-full bg-destructive" />
          )}
          <Mic className="relative h-5 w-5" />
        </Button>
      )}
    </form>
  );
};
