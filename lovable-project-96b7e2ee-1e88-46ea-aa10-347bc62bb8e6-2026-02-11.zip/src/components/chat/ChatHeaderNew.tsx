import { ArrowLeft, Phone, Video, MoreVertical, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ChatWithParticipants } from '@/types/database';
import { PresenceIndicator } from './PresenceIndicator';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface UserPresence {
  user_id: string;
  status: 'online' | 'offline' | 'away';
  last_seen: string;
}

interface ChatHeaderNewProps {
  chat: ChatWithParticipants;
  currentUserId: string;
  onVideoCall: () => void;
  onVoiceCall: () => void;
  onBack?: () => void;
  getPresence?: (userId: string) => UserPresence | undefined;
  onEditGroup?: () => void;
  onEditContact?: () => void;
  getDisplayName?: (contactId: string, originalName: string | null) => string;
  getDisplayAvatar?: (contactId: string, originalAvatar: string | null) => string;
}

export const ChatHeaderNew = ({
  chat,
  currentUserId,
  onVideoCall,
  onVoiceCall,
  onBack,
  getPresence,
  onEditGroup,
  onEditContact,
  getDisplayName,
  getDisplayAvatar,
}: ChatHeaderNewProps) => {
  const otherUser = chat.participants.find((p) => p.id !== currentUserId);
  const presence = otherUser && getPresence ? getPresence(otherUser.id) : undefined;

  const getChatName = (): string => {
    if (chat.is_group && chat.group_name) return chat.group_name;
    if (!otherUser) return 'Chat';
    if (getDisplayName) {
      return getDisplayName(otherUser.id, otherUser.display_name);
    }
    return otherUser.display_name || otherUser.email || 'Chat';
  };

  const getChatAvatar = (): string => {
    if (chat.is_group && chat.group_avatar) return chat.group_avatar;
    if (!otherUser) return `https://api.dicebear.com/7.x/avataaars/svg?seed=default`;
    if (getDisplayAvatar) {
      return getDisplayAvatar(otherUser.id, otherUser.avatar_url);
    }
    return otherUser.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${otherUser.email}`;
  };

  const getStatusText = (): string => {
    if (chat.is_group) {
      return `${chat.participants.length} participantes`;
    }
    
    if (presence) {
      if (presence.status === 'online') return 'En línea';
      if (presence.status === 'away') return 'Ausente';
      return `Última vez ${formatDistanceToNow(new Date(presence.last_seen), {
        addSuffix: true,
        locale: es,
      })}`;
    }
    
    return 'Desconectado';
  };

  return (
    <div className="glass flex items-center gap-3 border-b px-4 py-2.5">
      {onBack && (
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="text-primary hover:bg-transparent md:hidden"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
      )}

      <div className="relative">
        <img
          src={getChatAvatar()}
          alt={getChatName()}
          className="h-9 w-9 rounded-full bg-secondary object-cover"
        />
        {presence && !chat.is_group && (
          <PresenceIndicator status={presence.status} size="sm" />
        )}
      </div>

      <div className="flex-1 min-w-0">
        <h2 className="text-[15px] font-semibold text-foreground truncate">
          {getChatName()}
        </h2>
        <p className="text-xs text-muted-foreground">
          {getStatusText()}
        </p>
      </div>

      <div className="flex items-center gap-0.5">
        <Button
          variant="ghost"
          size="icon"
          onClick={onVideoCall}
          className="h-8 w-8 text-primary hover:bg-accent"
        >
          <Video className="h-[18px] w-[18px]" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={onVoiceCall}
          className="h-8 w-8 text-primary hover:bg-accent"
        >
          <Phone className="h-[18px] w-[18px]" />
        </Button>
        {(chat.is_group && onEditGroup) || (!chat.is_group && onEditContact) ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-muted-foreground hover:bg-accent"
              >
                <MoreVertical className="h-[18px] w-[18px]" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="rounded-xl shadow-lg border">
              {chat.is_group && onEditGroup ? (
                <DropdownMenuItem onClick={onEditGroup} className="rounded-lg">
                  <Settings className="mr-2 h-4 w-4" />
                  Configuración del grupo
                </DropdownMenuItem>
              ) : onEditContact ? (
                <DropdownMenuItem onClick={onEditContact} className="rounded-lg">
                  <Settings className="mr-2 h-4 w-4" />
                  Personalizar contacto
                </DropdownMenuItem>
              ) : null}
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-muted-foreground hover:bg-accent"
          >
            <MoreVertical className="h-[18px] w-[18px]" />
          </Button>
        )}
      </div>
    </div>
  );
};