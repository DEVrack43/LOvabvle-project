import { useState } from 'react';
import { Search, Users } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { User } from '@/types/chat';
import { mockUsers } from '@/data/mockData';
import { cn } from '@/lib/utils';

interface NewChatDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelectUser: (user: User) => void;
  onCreateGroup: (users: User[], groupName: string) => void;
}

export const NewChatDialog = ({
  open,
  onOpenChange,
  onSelectUser,
  onCreateGroup,
}: NewChatDialogProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isGroupMode, setIsGroupMode] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<User[]>([]);
  const [groupName, setGroupName] = useState('');

  const filteredUsers = mockUsers.filter((user) =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUserClick = (user: User) => {
    if (isGroupMode) {
      setSelectedUsers((prev) =>
        prev.some((u) => u.id === user.id)
          ? prev.filter((u) => u.id !== user.id)
          : [...prev, user]
      );
    } else {
      onSelectUser(user);
      onOpenChange(false);
    }
  };

  const handleCreateGroup = () => {
    if (selectedUsers.length > 0 && groupName.trim()) {
      onCreateGroup(selectedUsers, groupName.trim());
      setSelectedUsers([]);
      setGroupName('');
      setIsGroupMode(false);
      onOpenChange(false);
    }
  };

  const resetDialog = () => {
    setSearchQuery('');
    setIsGroupMode(false);
    setSelectedUsers([]);
    setGroupName('');
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(isOpen) => {
        if (!isOpen) resetDialog();
        onOpenChange(isOpen);
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isGroupMode ? 'Nuevo grupo' : 'Nuevo chat'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {isGroupMode && (
            <Input
              placeholder="Nombre del grupo"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
            />
          )}

          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Buscar contacto"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {!isGroupMode && (
            <Button
              variant="ghost"
              className="w-full justify-start gap-3 text-primary"
              onClick={() => setIsGroupMode(true)}
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
                <Users className="h-5 w-5 text-primary-foreground" />
              </div>
              <span>Nuevo grupo</span>
            </Button>
          )}

          <div className="max-h-[300px] overflow-y-auto">
            {filteredUsers.map((user) => {
              const isSelected = selectedUsers.some((u) => u.id === user.id);
              return (
                <button
                  key={user.id}
                  onClick={() => handleUserClick(user)}
                  className={cn(
                    'flex w-full items-center gap-3 rounded-lg p-3 transition-colors hover:bg-accent',
                    isSelected && 'bg-accent'
                  )}
                >
                  <div className="relative">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="h-10 w-10 rounded-full bg-muted"
                    />
                    {user.status === 'online' && (
                      <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-background bg-online" />
                    )}
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium">{user.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {user.status === 'online'
                        ? 'En línea'
                        : user.status === 'away'
                        ? 'Ausente'
                        : 'Desconectado'}
                    </p>
                  </div>
                  {isGroupMode && isSelected && (
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                      ✓
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {isGroupMode && selectedUsers.length > 0 && (
            <Button
              onClick={handleCreateGroup}
              disabled={!groupName.trim()}
              className="w-full"
            >
              Crear grupo ({selectedUsers.length} participantes)
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
