import { DbMessage, Profile } from '@/types/database';
import { useSignedUrl } from '@/hooks/useSignedUrl';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { Check, CheckCheck, FileIcon, Volume2, Loader2 } from 'lucide-react';

interface MessageBubbleProps {
  message: DbMessage;
  isLast: boolean;
  participants: Profile[];
  currentUserId: string;
  isGroup: boolean;
  getDisplayName?: (contactId: string, originalName: string | null) => string;
}

export const MessageBubbleNew = ({ message, isLast, participants, currentUserId, isGroup, getDisplayName }: MessageBubbleProps) => {
  const isSent = message.sender_id === currentUserId;
  
  const { url: signedUrl, loading: urlLoading } = useSignedUrl(
    message.type !== 'text' ? message.file_url : null
  );

  const getStatusIcon = () => {
    if (!isSent) return null;
    if (message.status === 'read') {
      return <CheckCheck className="h-3.5 w-3.5 text-primary-foreground/60" />;
    }
    if (message.status === 'delivered') {
      return <CheckCheck className="h-3.5 w-3.5 text-primary-foreground/40" />;
    }
    return <Check className="h-3.5 w-3.5 text-primary-foreground/40" />;
  };

  const renderContent = () => {
    switch (message.type) {
      case 'image':
        return (
          <div className="space-y-1">
            {urlLoading ? (
              <div className="flex h-[150px] w-[250px] items-center justify-center rounded-2xl bg-secondary">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : signedUrl ? (
              <img 
                src={signedUrl} 
                alt={message.file_name || 'Image'} 
                className="max-w-[250px] rounded-2xl"
              />
            ) : (
              <div className="flex h-[150px] w-[250px] items-center justify-center rounded-2xl bg-secondary text-sm text-muted-foreground">
                Imagen no disponible
              </div>
            )}
            {message.content && (
              <p className={cn(
                'text-[15px] leading-relaxed',
                isSent ? 'text-primary-foreground' : 'text-foreground'
              )}>{message.content}</p>
            )}
          </div>
        );
      case 'audio':
        return (
          <div className="flex items-center gap-2">
            <Volume2 className={cn('h-5 w-5', isSent ? 'text-primary-foreground/80' : 'text-primary')} />
            {urlLoading ? (
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            ) : signedUrl ? (
              <audio controls className="h-8 max-w-[200px]">
                <source src={signedUrl} type="audio/webm" />
                Tu navegador no soporta audio
              </audio>
            ) : (
              <span className={cn('text-sm', isSent ? 'text-primary-foreground/60' : 'text-muted-foreground')}>Audio no disponible</span>
            )}
          </div>
        );
      case 'file':
        return urlLoading ? (
          <div className="flex items-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            <span className={cn('text-sm', isSent ? 'text-primary-foreground/60' : 'text-muted-foreground')}>Cargando...</span>
          </div>
        ) : signedUrl ? (
          <a 
            href={signedUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className={cn(
              'flex items-center gap-2 hover:underline',
              isSent ? 'text-primary-foreground' : 'text-primary'
            )}
          >
            <FileIcon className="h-5 w-5" />
            <span className="text-sm">{message.file_name || 'Archivo'}</span>
          </a>
        ) : (
          <div className={cn('flex items-center gap-2', isSent ? 'text-primary-foreground/60' : 'text-muted-foreground')}>
            <FileIcon className="h-5 w-5" />
            <span className="text-sm">Archivo no disponible</span>
          </div>
        );
      default:
        return (
          <p className={cn(
            'text-[15px] leading-relaxed',
            isSent ? 'text-primary-foreground' : 'text-foreground'
          )}>
            {message.content}
          </p>
        );
    }
  };

  return (
    <div
      className={cn(
        'flex w-full animate-message-in',
        isSent ? 'justify-end' : 'justify-start'
      )}
    >
      <div
        className={cn(
          'relative max-w-[70%] rounded-[18px] px-3.5 py-2 ios-press',
          isSent
            ? 'rounded-br-[4px] bg-chat-bubble-sent'
            : 'rounded-bl-[4px] bg-chat-bubble-received'
        )}
      >
        {!isSent && (() => {
          const sender = participants.find(p => p.id === message.sender_id);
          const senderName = getDisplayName 
            ? getDisplayName(message.sender_id, sender?.display_name || null)
            : sender?.display_name || 'Usuario';
          return (
            <p className="mb-0.5 text-xs font-semibold text-primary">
              {senderName}
            </p>
          );
        })()}
        {renderContent()}
        <div
          className={cn(
            'mt-0.5 flex items-center gap-1',
            isSent ? 'justify-end' : 'justify-start'
          )}
        >
          <span className={cn(
            'text-[10px]',
            isSent ? 'text-primary-foreground/50' : 'text-muted-foreground'
          )}>
            {format(new Date(message.created_at), 'HH:mm')}
          </span>
          {getStatusIcon()}
        </div>
      </div>
    </div>
  );
};