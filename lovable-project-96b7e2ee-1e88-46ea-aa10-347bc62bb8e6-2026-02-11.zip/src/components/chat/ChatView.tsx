import { Chat, Message } from '@/types/chat';
import { ChatHeader } from './ChatHeader';
import { ChatMessages } from './ChatMessages';
import { MessageInput } from './MessageInput';
import { currentUser } from '@/data/mockData';

interface ChatViewProps {
  chat: Chat;
  onSendMessage: (chatId: string, content: string) => void;
  onVideoCall: () => void;
  onVoiceCall: () => void;
  onBack?: () => void;
}

export const ChatView = ({
  chat,
  onSendMessage,
  onVideoCall,
  onVoiceCall,
  onBack,
}: ChatViewProps) => {
  const handleSendMessage = (content: string) => {
    onSendMessage(chat.id, content);
  };

  return (
    <div className="flex h-full flex-col">
      <ChatHeader
        chat={chat}
        onVideoCall={onVideoCall}
        onVoiceCall={onVoiceCall}
        onBack={onBack}
      />
      <ChatMessages messages={chat.messages} />
      <MessageInput onSendMessage={handleSendMessage} />
    </div>
  );
};
