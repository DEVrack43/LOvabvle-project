import { useState, useRef } from 'react';
import { Plus, X, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { UserStories, useStories } from '@/hooks/useStories';
import { useAuth } from '@/hooks/useAuth';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

interface StoriesBarProps {
  userStories: UserStories[];
  onViewStory: (userStories: UserStories) => void;
}

export const StoriesBar = ({ userStories, onViewStory }: StoriesBarProps) => {
  const { profile, user } = useAuth();
  const { createStory, uploadStoryMedia } = useStories();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [storyText, setStoryText] = useState('');
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const myStories = userStories.find((us) => us.user.id === user?.id);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
      toast.error('Solo se permiten imágenes o videos');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast.error('El archivo no puede superar 10MB');
      return;
    }

    setUploading(true);
    try {
      const mediaUrl = await uploadStoryMedia(file);
      if (mediaUrl) {
        const mediaType = file.type.startsWith('video/') ? 'video' : 'image';
        await createStory(null, mediaUrl, mediaType);
        toast.success('Historia publicada');
        setIsCreateOpen(false);
      } else {
        toast.error('Error al subir el archivo');
      }
    } catch (error) {
      console.error('Error uploading story:', error);
      toast.error('Error al publicar la historia');
    } finally {
      setUploading(false);
    }
  };

  const handleTextStory = async () => {
    if (!storyText.trim()) {
      toast.error('Escribe algo para tu historia');
      return;
    }

    setUploading(true);
    try {
      await createStory(storyText.trim(), null, 'text');
      toast.success('Historia publicada');
      setStoryText('');
      setIsCreateOpen(false);
    } catch (error) {
      console.error('Error creating story:', error);
      toast.error('Error al publicar la historia');
    } finally {
      setUploading(false);
    }
  };

  return (
    <>
      <div className="flex gap-3 overflow-x-auto px-3 py-3 scrollbar-thin">
        {/* Add Story Button */}
        <button
          onClick={() => setIsCreateOpen(true)}
          className="flex flex-col items-center gap-1"
        >
          <div className="relative h-16 w-16 shrink-0">
            <img
              src={profile?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile?.email}`}
              alt="Tu historia"
              className="h-full w-full rounded-full bg-muted object-cover"
            />
            <span className="absolute bottom-0 right-0 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground">
              <Plus className="h-3 w-3" />
            </span>
          </div>
          <span className="text-xs text-muted-foreground">
            {myStories ? 'Agregar' : 'Mi estado'}
          </span>
        </button>

        {/* User Stories */}
        {userStories
          .filter((us) => us.user.id !== user?.id)
          .map((us) => (
            <button
              key={us.user.id}
              onClick={() => onViewStory(us)}
              className="flex flex-col items-center gap-1"
            >
              <div
                className={cn(
                  'h-16 w-16 shrink-0 rounded-full p-0.5',
                  us.hasUnviewed
                    ? 'bg-gradient-to-tr from-primary to-accent'
                    : 'bg-muted-foreground/30'
                )}
              >
                <img
                  src={us.user.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${us.user.id}`}
                  alt={us.user.display_name || 'Usuario'}
                  className="h-full w-full rounded-full bg-background object-cover p-0.5"
                />
              </div>
              <span className="max-w-[64px] truncate text-xs">
                {us.user.display_name || 'Usuario'}
              </span>
            </button>
          ))}
      </div>

      {/* Create Story Dialog */}
      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent className="sm:max-w-md">
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Crear historia</h2>
            
            <div className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
              >
                {uploading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Plus className="h-4 w-4" />
                )}
                Subir foto o video
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                onChange={handleFileSelect}
                className="hidden"
              />

              <div className="relative">
                <Input
                  placeholder="Escribe un estado de texto..."
                  value={storyText}
                  onChange={(e) => setStoryText(e.target.value)}
                  maxLength={500}
                />
              </div>

              {storyText && (
                <Button
                  onClick={handleTextStory}
                  disabled={uploading}
                  className="w-full"
                >
                  {uploading ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : null}
                  Publicar texto
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
