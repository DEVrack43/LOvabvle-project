import { Phone, Video, MoreVertical, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Chat, User } from '@/types/chat';
import { currentUser } from '@/data/mockData';
import { cn } from '@/lib/utils';

interface ChatHeaderProps {
  chat: Chat;
  onVideoCall: () => void;
  onVoiceCall: () => void;
  onBack?: () => void;
}

export const ChatHeader = ({ chat, onVideoCall, onVoiceCall, onBack }: ChatHeaderProps) => {
  const getChatName = (): string => {
    if (chat.isGroup && chat.groupName) return chat.groupName;
    const otherUser = chat.participants.find((p) => p.id !== currentUser.id);
    return otherUser?.name || 'Chat';
  };

  const getChatAvatar = (): string => {
    if (chat.isGroup && chat.groupAvatar) return chat.groupAvatar;
    const otherUser = chat.participants.find((p) => p.id !== currentUser.id);
    return otherUser?.avatar || '';
  };

  const getStatusText = (): string => {
    if (chat.isGroup) {
      return `${chat.participants.length} participantes`;
    }
    const otherUser = chat.participants.find((p) => p.id !== currentUser.id);
    if (otherUser?.status === 'online') return 'En línea';
    if (otherUser?.status === 'away') return 'Ausente';
    return 'Desconectado';
  };

  const getOtherUserStatus = (): User['status'] | undefined => {
    if (chat.isGroup) return undefined;
    const otherUser = chat.participants.find((p) => p.id !== currentUser.id);
    return otherUser?.status;
  };

  const status = getOtherUserStatus();

  return (
    <div className="flex items-center justify-between border-b bg-card px-4 py-3 shadow-chat">
      <div className="flex items-center gap-3">
        {onBack && (
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={onBack}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
        )}
        <div className="relative">
          <img
            src={getChatAvatar()}
            alt={getChatName()}
            className="h-10 w-10 rounded-full bg-muted"
          />
          {status === 'online' && (
            <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-card bg-online" />
          )}
        </div>
        <div>
          <h2 className="font-semibold">{getChatName()}</h2>
          <p
            className={cn(
              'text-sm',
              status === 'online' ? 'text-online' : 'text-muted-foreground'
            )}
          >
            {getStatusText()}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="text-muted-foreground hover:text-primary"
          onClick={onVideoCall}
        >
          <Video className="h-5 w-5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="text-muted-foreground hover:text-primary"
          onClick={onVoiceCall}
        >
          <Phone className="h-5 w-5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="text-muted-foreground hover:text-foreground"
        >
          <MoreVertical className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
};
