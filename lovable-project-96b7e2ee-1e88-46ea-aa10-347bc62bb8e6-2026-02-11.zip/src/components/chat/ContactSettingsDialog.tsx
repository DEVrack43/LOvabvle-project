import { useState, useRef, useEffect } from 'react';
import { Camera, Loader2, RotateCcw } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Profile } from '@/types/database';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';

interface ContactSettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contact: Profile;
  currentOverride?: {
    custom_name: string | null;
    custom_avatar: string | null;
  };
  onSave: (customName: string | null, customAvatar: string | null) => Promise<boolean>;
  onReset: () => Promise<boolean>;
}

export const ContactSettingsDialog = ({
  open,
  onOpenChange,
  contact,
  currentOverride,
  onSave,
  onReset,
}: ContactSettingsDialogProps) => {
  const { user } = useAuth();
  const [customName, setCustomName] = useState(currentOverride?.custom_name || '');
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(currentOverride?.custom_avatar || null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Reset state when dialog opens
  useEffect(() => {
    if (open) {
      setCustomName(currentOverride?.custom_name || '');
      setPreviewUrl(currentOverride?.custom_avatar || null);
    }
  }, [open, currentOverride]);

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Solo se permiten imágenes');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error('La imagen no puede superar 5MB');
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const filePath = `contact-overrides/${user.id}/${contact.id}.${fileExt}`;

      // Upload to avatars bucket
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      const newUrl = `${data.publicUrl}?t=${Date.now()}`;
      setPreviewUrl(newUrl);
      toast.success('Imagen cargada');
    } catch (error) {
      console.error('Error uploading avatar:', error);
      toast.error('Error al subir la imagen');
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const nameToSave = customName.trim() || null;
      const success = await onSave(nameToSave, previewUrl);
      
      if (success) {
        toast.success('Contacto personalizado');
        onOpenChange(false);
      } else {
        toast.error('Error al guardar');
      }
    } finally {
      setSaving(false);
    }
  };

  const handleReset = async () => {
    setSaving(true);
    try {
      const success = await onReset();
      
      if (success) {
        setCustomName('');
        setPreviewUrl(null);
        toast.success('Personalización eliminada');
        onOpenChange(false);
      } else {
        toast.error('Error al restablecer');
      }
    } finally {
      setSaving(false);
    }
  };

  const originalAvatar = contact.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${contact.id}`;
  const displayAvatar = previewUrl || originalAvatar;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Personalizar contacto</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Avatar */}
          <div className="flex flex-col items-center gap-3">
            <div className="relative">
              <img
                src={displayAvatar}
                alt={customName || contact.display_name || 'Contacto'}
                className="h-24 w-24 rounded-full bg-muted object-cover"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="absolute bottom-0 right-0 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground hover:bg-primary/90"
              >
                {uploading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Camera className="h-4 w-4" />
                )}
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                className="hidden"
              />
            </div>
            <p className="text-sm text-muted-foreground">
              Nombre original: {contact.display_name || 'Sin nombre'}
            </p>
          </div>

          {/* Custom Name */}
          <div className="space-y-2">
            <Label htmlFor="customName">Apodo personalizado</Label>
            <Input
              id="customName"
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
              placeholder={contact.display_name || 'Nombre personalizado'}
              maxLength={50}
            />
            <p className="text-xs text-muted-foreground">
              Solo tú verás este nombre
            </p>
          </div>
        </div>

        <div className="flex justify-between gap-2">
          <Button 
            variant="outline" 
            onClick={handleReset}
            disabled={saving || (!currentOverride?.custom_name && !currentOverride?.custom_avatar)}
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            Restablecer
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSave} disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Guardar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
