import { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Trash2 } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { UserStories, Story } from '@/hooks/useStories';
import { useAuth } from '@/hooks/useAuth';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface StoryViewerProps {
  userStories: UserStories | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onViewStory: (storyId: string) => void;
  onDeleteStory?: (storyId: string) => void;
}

export const StoryViewer = ({
  userStories,
  open,
  onOpenChange,
  onViewStory,
  onDeleteStory,
}: StoryViewerProps) => {
  const { user } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);

  const stories = userStories?.stories || [];
  const currentStory = stories[currentIndex];
  const isOwnStory = userStories?.user.id === user?.id;

  useEffect(() => {
    if (!open || !currentStory) return;

    // Mark story as viewed
    if (!currentStory.viewed_by_me && !isOwnStory) {
      onViewStory(currentStory.id);
    }

    // Progress bar animation
    setProgress(0);
    const duration = currentStory.media_type === 'video' ? 15000 : 5000;
    const interval = 50;
    const increment = (interval / duration) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          // Go to next story or close
          if (currentIndex < stories.length - 1) {
            setCurrentIndex((i) => i + 1);
          } else {
            onOpenChange(false);
          }
          return 0;
        }
        return prev + increment;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [open, currentIndex, currentStory, isOwnStory, stories.length, onViewStory, onOpenChange]);

  useEffect(() => {
    if (open) {
      setCurrentIndex(0);
      setProgress(0);
    }
  }, [open, userStories]);

  const goToPrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex((i) => i - 1);
      setProgress(0);
    }
  };

  const goToNext = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex((i) => i + 1);
      setProgress(0);
    } else {
      onOpenChange(false);
    }
  };

  if (!userStories || !currentStory) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="h-[90vh] max-w-md overflow-hidden border-0 bg-black p-0">
        {/* Progress bars */}
        <div className="absolute left-0 right-0 top-0 z-10 flex gap-1 p-2">
          {stories.map((_, index) => (
            <div key={index} className="h-0.5 flex-1 overflow-hidden rounded-full bg-white/30">
              <div
                className="h-full bg-white transition-all duration-100 ease-linear"
                style={{
                  width: index < currentIndex ? '100%' : index === currentIndex ? `${progress}%` : '0%',
                }}
              />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="absolute left-0 right-0 top-4 z-10 flex items-center justify-between px-4 pt-4">
          <div className="flex items-center gap-3">
            <img
              src={userStories.user.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${userStories.user.id}`}
              alt={userStories.user.display_name || 'Usuario'}
              className="h-10 w-10 rounded-full bg-card"
            />
            <div>
              <p className="font-medium text-white">
                {isOwnStory ? 'Mi estado' : userStories.user.display_name || 'Usuario'}
              </p>
              <p className="text-xs text-white/70">
                {formatDistanceToNow(new Date(currentStory.created_at), {
                  addSuffix: true,
                  locale: es,
                })}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isOwnStory && onDeleteStory && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onDeleteStory(currentStory.id)}
                className="text-white hover:bg-white/20"
              >
                <Trash2 className="h-5 w-5" />
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onOpenChange(false)}
              className="text-white hover:bg-white/20"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Story Content */}
        <div className="flex h-full items-center justify-center">
          {currentStory.media_type === 'text' ? (
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary to-primary/70 p-8">
              <p className="text-center text-2xl font-medium text-white">
                {currentStory.content}
              </p>
            </div>
          ) : currentStory.media_type === 'video' ? (
            <video
              src={currentStory.media_url || ''}
              autoPlay
              muted
              className="h-full w-full object-contain"
            />
          ) : (
            <img
              src={currentStory.media_url || ''}
              alt="Historia"
              className="h-full w-full object-contain"
            />
          )}
        </div>

        {/* Navigation buttons */}
        <button
          onClick={goToPrevious}
          className="absolute bottom-0 left-0 top-20 w-1/3"
          disabled={currentIndex === 0}
        />
        <button
          onClick={goToNext}
          className="absolute bottom-0 right-0 top-20 w-1/3"
        />
      </DialogContent>
    </Dialog>
  );
};
