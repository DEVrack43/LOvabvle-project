import { useState } from 'react';
import { Chat, User, Message } from '@/types/chat';
import { mockChats, currentUser, mockUsers } from '@/data/mockData';
import { ChatSidebar } from './ChatSidebar';
import { ChatView } from './ChatView';
import { EmptyChat } from './EmptyChat';
import { NewChatDialog } from './NewChatDialog';
import { CallDialog } from './CallDialog';
import { cn } from '@/lib/utils';

export const ChattingApp = () => {
  const [chats, setChats] = useState<Chat[]>(mockChats);
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [isNewChatOpen, setIsNewChatOpen] = useState(false);
  const [callState, setCallState] = useState<{
    isOpen: boolean;
    user: User | null;
    isVideo: boolean;
  }>({
    isOpen: false,
    user: null,
    isVideo: false,
  });

  const selectedChat = chats.find((chat) => chat.id === selectedChatId);

  const handleSendMessage = (chatId: string, content: string) => {
    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      content,
      senderId: currentUser.id,
      timestamp: new Date(),
      status: 'sent',
      type: 'text',
    };

    setChats((prev) =>
      prev.map((chat) =>
        chat.id === chatId
          ? {
              ...chat,
              messages: [...chat.messages, newMessage],
              lastMessage: newMessage,
            }
          : chat
      )
    );

    // Simulate message delivery
    setTimeout(() => {
      setChats((prev) =>
        prev.map((chat) =>
          chat.id === chatId
            ? {
                ...chat,
                messages: chat.messages.map((msg) =>
                  msg.id === newMessage.id ? { ...msg, status: 'delivered' } : msg
                ),
              }
            : chat
        )
      );
    }, 1000);
  };

  const handleSelectUser = (user: User) => {
    // Check if chat exists
    const existingChat = chats.find(
      (chat) =>
        !chat.isGroup &&
        chat.participants.some((p) => p.id === user.id)
    );

    if (existingChat) {
      setSelectedChatId(existingChat.id);
    } else {
      // Create new chat
      const newChat: Chat = {
        id: `chat-${Date.now()}`,
        participants: [currentUser, user],
        messages: [],
        unreadCount: 0,
        isGroup: false,
      };
      setChats((prev) => [newChat, ...prev]);
      setSelectedChatId(newChat.id);
    }
  };

  const handleCreateGroup = (users: User[], groupName: string) => {
    const newChat: Chat = {
      id: `chat-${Date.now()}`,
      participants: [currentUser, ...users],
      messages: [],
      unreadCount: 0,
      isGroup: true,
      groupName,
      groupAvatar: `https://api.dicebear.com/7.x/identicon/svg?seed=${groupName}`,
    };
    setChats((prev) => [newChat, ...prev]);
    setSelectedChatId(newChat.id);
  };

  const handleVideoCall = () => {
    if (!selectedChat) return;
    const otherUser = selectedChat.participants.find(
      (p) => p.id !== currentUser.id
    );
    if (otherUser) {
      setCallState({ isOpen: true, user: otherUser, isVideo: true });
    }
  };

  const handleVoiceCall = () => {
    if (!selectedChat) return;
    const otherUser = selectedChat.participants.find(
      (p) => p.id !== currentUser.id
    );
    if (otherUser) {
      setCallState({ isOpen: true, user: otherUser, isVideo: false });
    }
  };

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background">
      {/* Sidebar */}
      <div
        className={cn(
          'h-full w-full shrink-0 border-r md:w-[380px]',
          selectedChatId && 'hidden md:block'
        )}
      >
        <ChatSidebar
          chats={chats}
          selectedChatId={selectedChatId}
          onSelectChat={setSelectedChatId}
          onNewChat={() => setIsNewChatOpen(true)}
        />
      </div>

      {/* Chat Area */}
      <div
        className={cn(
          'flex-1',
          !selectedChatId && 'hidden md:block'
        )}
      >
        {selectedChat ? (
          <ChatView
            chat={selectedChat}
            onSendMessage={handleSendMessage}
            onVideoCall={handleVideoCall}
            onVoiceCall={handleVoiceCall}
            onBack={() => setSelectedChatId(null)}
          />
        ) : (
          <EmptyChat />
        )}
      </div>

      {/* Dialogs */}
      <NewChatDialog
        open={isNewChatOpen}
        onOpenChange={setIsNewChatOpen}
        onSelectUser={handleSelectUser}
        onCreateGroup={handleCreateGroup}
      />

      <CallDialog
        open={callState.isOpen}
        onOpenChange={(open) =>
          setCallState((prev) => ({ ...prev, isOpen: open }))
        }
        user={callState.user}
        isVideo={callState.isVideo}
      />
    </div>
  );
};
