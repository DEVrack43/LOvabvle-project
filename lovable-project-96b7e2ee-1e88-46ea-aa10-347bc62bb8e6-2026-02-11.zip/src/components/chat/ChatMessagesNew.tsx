import { useEffect, useRef } from 'react';
import { DbMessage, Profile } from '@/types/database';
import { MessageBubbleNew } from './MessageBubbleNew';

interface ChatMessagesNewProps {
  messages: DbMessage[];
  participants: Profile[];
  currentUserId: string;
  isGroup: boolean;
  getDisplayName?: (contactId: string, originalName: string | null) => string;
}

export const ChatMessagesNew = ({ messages, participants, currentUserId, isGroup, getDisplayName }: ChatMessagesNewProps) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="flex-1 overflow-y-auto bg-background p-4 scrollbar-thin">
      <div className="mx-auto flex max-w-3xl flex-col gap-2">
        {messages.length === 0 ? (
          <div className="flex h-full items-center justify-center text-muted-foreground">
            <p>No hay mensajes aún. ¡Envía el primero!</p>
          </div>
        ) : (
          messages.map((message, index) => (
            <MessageBubbleNew
              key={message.id}
              message={message}
              isLast={index === messages.length - 1}
              participants={participants}
              currentUserId={currentUserId}
              isGroup={isGroup}
              getDisplayName={getDisplayName}
            />
          ))
        )}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};
