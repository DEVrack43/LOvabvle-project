import { useState } from 'react';
import { Search, Plus, MoreVertical, LogOut, Trash2, User } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ChatWithParticipants } from '@/types/database';
import { Profile } from '@/types/database';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { PresenceIndicator } from './PresenceIndicator';
import { StoriesBar } from './StoriesBar';
import { UserStories } from '@/hooks/useStories';

interface UserPresence {
  user_id: string;
  status: 'online' | 'offline' | 'away';
  last_seen: string;
}

interface ChatSidebarNewProps {
  chats: ChatWithParticipants[];
  currentUser: Profile;
  selectedChatId: string | null;
  onSelectChat: (chatId: string) => void;
  onNewChat: () => void;
  onDeleteChat: (chatId: string) => void;
  onSignOut: () => void;
  onEditProfile: () => void;
  getPresence?: (userId: string) => UserPresence | undefined;
  userStories?: UserStories[];
  onViewStory?: (userStories: UserStories) => void;
  getDisplayName?: (contactId: string, originalName: string | null) => string;
  getDisplayAvatar?: (contactId: string, originalAvatar: string | null) => string;
}

export const ChatSidebarNew = ({
  chats,
  currentUser,
  selectedChatId,
  onSelectChat,
  onNewChat,
  onDeleteChat,
  onSignOut,
  onEditProfile,
  getPresence,
  userStories = [],
  onViewStory,
  getDisplayName,
  getDisplayAvatar,
}: ChatSidebarNewProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [chatToDelete, setChatToDelete] = useState<string | null>(null);

  const getChatName = (chat: ChatWithParticipants): string => {
    if (chat.is_group && chat.group_name) return chat.group_name;
    const otherUser = chat.participants.find((p) => p.id !== currentUser.id);
    if (!otherUser) return 'Chat';
    if (getDisplayName) {
      return getDisplayName(otherUser.id, otherUser.display_name);
    }
    return otherUser.display_name || otherUser.email || 'Chat';
  };

  const getChatAvatar = (chat: ChatWithParticipants): string => {
    if (chat.is_group && chat.group_avatar) return chat.group_avatar;
    const otherUser = chat.participants.find((p) => p.id !== currentUser.id);
    if (!otherUser) return `https://api.dicebear.com/7.x/avataaars/svg?seed=default`;
    if (getDisplayAvatar) {
      return getDisplayAvatar(otherUser.id, otherUser.avatar_url);
    }
    return otherUser.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${otherUser.email}`;
  };

  const getOtherUserId = (chat: ChatWithParticipants): string | null => {
    if (chat.is_group) return null;
    const otherUser = chat.participants.find((p) => p.id !== currentUser.id);
    return otherUser?.id || null;
  };

  const filteredChats = chats.filter((chat) =>
    getChatName(chat).toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDeleteConfirm = () => {
    if (chatToDelete) {
      onDeleteChat(chatToDelete);
      setChatToDelete(null);
    }
  };

  return (
    <div className="flex h-full w-full flex-col bg-card">
      {/* Header */}
      <div className="glass flex items-center justify-between border-b px-4 py-2.5">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={currentUser.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUser.email}`}
              alt={currentUser.display_name || ''}
              className="h-9 w-9 rounded-full bg-secondary object-cover"
            />
            <PresenceIndicator status="online" size="sm" />
          </div>
          <span className="text-lg font-semibold tracking-tight text-foreground">
            Mensajes
          </span>
        </div>
        <div className="flex items-center gap-0.5">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-primary hover:bg-accent"
            onClick={onNewChat}
          >
            <Plus className="h-5 w-5" strokeWidth={2.5} />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-muted-foreground hover:bg-accent"
              >
                <MoreVertical className="h-[18px] w-[18px]" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="rounded-xl shadow-lg border">
              <DropdownMenuItem onClick={onEditProfile} className="rounded-lg">
                <User className="mr-2 h-4 w-4" />
                Editar perfil
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={onSignOut} className="rounded-lg text-destructive">
                <LogOut className="mr-2 h-4 w-4" />
                Cerrar sesión
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Stories Bar */}
      {onViewStory && (
        <StoriesBar userStories={userStories} onViewStory={onViewStory} />
      )}

      {/* Search */}
      <div className="px-3 py-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-9 rounded-lg border-0 bg-secondary pl-10 text-sm focus-visible:ring-1 focus-visible:ring-primary"
          />
        </div>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        {filteredChats.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-8 text-center text-muted-foreground">
            <p className="text-sm">No tienes chats aún</p>
            <Button variant="link" onClick={onNewChat} className="mt-2 text-primary">
              Iniciar un nuevo chat
            </Button>
          </div>
        ) : (
          filteredChats.map((chat) => {
            const lastMessage = chat.lastMessage;
            const otherUserId = getOtherUserId(chat);
            const presence = otherUserId && getPresence ? getPresence(otherUserId) : undefined;
            
            return (
              <div
                key={chat.id}
                style={{ animationDelay: `${filteredChats.indexOf(chat) * 30}ms` }}
                className={cn(
                  'group flex w-full items-center gap-3 px-4 py-2.5 ios-press cursor-pointer transition-colors hover:bg-accent animate-ios-list-item',
                  selectedChatId === chat.id && 'bg-primary/10'
                )}
              >
                <button
                  onClick={() => onSelectChat(chat.id)}
                  className="flex flex-1 items-center gap-3 min-w-0"
                >
                  <div className="relative shrink-0">
                    <img
                      src={getChatAvatar(chat)}
                      alt={getChatName(chat)}
                      className="h-11 w-11 rounded-full bg-secondary object-cover"
                    />
                    {presence && !chat.is_group && (
                      <PresenceIndicator status={presence.status} />
                    )}
                  </div>
                  <div className="flex-1 overflow-hidden text-left">
                    <div className="flex items-center justify-between">
                      <span className="text-[15px] font-semibold text-foreground truncate">{getChatName(chat)}</span>
                      {lastMessage && (
                        <span className="text-[11px] text-muted-foreground ml-2 shrink-0">
                          {formatDistanceToNow(new Date(lastMessage.created_at), {
                            addSuffix: false,
                            locale: es,
                          })}
                        </span>
                      )}
                    </div>
                    <p className="truncate text-[13px] text-muted-foreground mt-0.5">
                      {lastMessage?.type === 'audio' ? '🎤 Mensaje de voz' :
                       lastMessage?.type === 'image' ? '📷 Imagen' :
                       lastMessage?.type === 'file' ? '📎 Archivo' :
                       lastMessage?.content || 'Sin mensajes'}
                    </p>
                  </div>
                </button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 opacity-0 transition-opacity group-hover:opacity-100 text-muted-foreground hover:text-destructive hover:bg-transparent"
                  onClick={() => setChatToDelete(chat.id)}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            );
          })
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!chatToDelete} onOpenChange={() => setChatToDelete(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar este chat?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción eliminará el chat de tu lista. Los otros participantes aún podrán ver los mensajes.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-xl">Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};