import { Phone, PhoneOff, Video } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface IncomingCallDialogProps {
  open: boolean;
  callerName: string;
  callerAvatar: string;
  isVideo: boolean;
  onAccept: () => void;
  onReject: () => void;
}

export const IncomingCallDialog = ({
  open,
  callerName,
  callerAvatar,
  isVideo,
  onAccept,
  onReject,
}: IncomingCallDialogProps) => {
  return (
    <Dialog open={open}>
      <DialogContent className="max-w-sm overflow-hidden rounded-2xl border-0 bg-gradient-to-b from-primary/90 to-primary p-0">
        <DialogTitle className="sr-only">Llamada entrante de {callerName}</DialogTitle>
        <div className="flex flex-col items-center px-8 py-12 text-primary-foreground">
          {/* Avatar */}
          <div className="relative">
            <img
              src={callerAvatar}
              alt={callerName}
              className="h-28 w-28 animate-pulse rounded-full bg-card ring-4 ring-primary-foreground/20"
            />
            <div className="absolute inset-0 animate-pulse-ring rounded-full bg-primary-foreground/30" />
          </div>

          {/* Name & Type */}
          <h2 className="mt-6 text-2xl font-semibold">{callerName}</h2>
          <p className="mt-2 flex items-center gap-2 text-primary-foreground/80">
            {isVideo ? (
              <>
                <Video className="h-4 w-4" />
                Videollamada entrante
              </>
            ) : (
              <>
                <Phone className="h-4 w-4" />
                Llamada entrante
              </>
            )}
          </p>

          {/* Controls */}
          <div className="mt-10 flex items-center gap-8">
            <Button
              variant="ghost"
              size="icon"
              onClick={onReject}
              className="h-16 w-16 rounded-full bg-destructive hover:bg-destructive/90"
            >
              <PhoneOff className="h-7 w-7" />
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={onAccept}
              className="h-16 w-16 rounded-full bg-primary hover:bg-primary/90"
            >
              {isVideo ? <Video className="h-7 w-7" /> : <Phone className="h-7 w-7" />}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
