import { MessageSquare } from 'lucide-react';

export const EmptyChat = () => {
  return (
    <div className="flex h-full flex-col items-center justify-center bg-background p-8">
      <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/10">
        <MessageSquare className="h-10 w-10 text-primary" />
      </div>
      <h2 className="mt-5 text-xl font-semibold tracking-tight text-foreground">Mensajes</h2>
      <p className="mt-2 max-w-xs text-center text-sm text-muted-foreground leading-relaxed">
        Selecciona una conversación para comenzar a chatear.
      </p>
      <div className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
        <span>🔒</span>
        <span>Cifrado de extremo a extremo</span>
      </div>
    </div>
  );
};