import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { ChatWithParticipants, DbMessage, Profile } from '@/types/database';

const CACHE_KEY = 'chatting_app_chats';
const CACHE_VERSION = 1;

interface CachedData {
  version: number;
  userId: string;
  chats: ChatWithParticipants[];
  timestamp: number;
}

function loadCachedChats(userId: string): ChatWithParticipants[] | null {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const cached: CachedData = JSON.parse(raw);
    if (cached.version !== CACHE_VERSION || cached.userId !== userId) return null;
    return cached.chats;
  } catch {
    return null;
  }
}

function saveCachedChats(userId: string, chats: ChatWithParticipants[]) {
  try {
    const data: CachedData = {
      version: CACHE_VERSION,
      userId,
      chats,
      timestamp: Date.now(),
    };
    localStorage.setItem(CACHE_KEY, JSON.stringify(data));
  } catch (e) {
    // Storage full or unavailable — silently ignore
    console.warn('Failed to cache chats:', e);
  }
}

export const useChats = () => {
  const { user } = useAuth();
  const [chats, setChats] = useState<ChatWithParticipants[]>([]);
  const [loading, setLoading] = useState(true);
  const initialLoadDone = useRef(false);

  // Load from cache on first mount
  useEffect(() => {
    if (!user || initialLoadDone.current) return;
    const cached = loadCachedChats(user.id);
    if (cached && cached.length > 0) {
      setChats(cached);
      setLoading(false);
      initialLoadDone.current = true;
    }
  }, [user]);

  const fetchChats = useCallback(async () => {
    if (!user) {
      setChats([]);
      setLoading(false);
      return;
    }

    try {
      // Get chat IDs where user is participant
      const { data: participations } = await supabase
        .from('chat_participants')
        .select('chat_id')
        .eq('user_id', user.id);

      if (!participations || participations.length === 0) {
        setChats([]);
        saveCachedChats(user.id, []);
        setLoading(false);
        return;
      }

      const chatIds = participations.map(p => p.chat_id);

      // Get chat details
      const { data: chatsData } = await supabase
        .from('chats')
        .select('*')
        .in('id', chatIds);

      if (!chatsData) {
        setChats([]);
        saveCachedChats(user.id, []);
        setLoading(false);
        return;
      }

      // Get all participants for these chats
      const { data: allParticipants } = await supabase
        .from('chat_participants')
        .select('chat_id, user_id')
        .in('chat_id', chatIds);

      // Get all user profiles using the public view (excludes email for privacy)
      const userIds = [...new Set(allParticipants?.map(p => p.user_id) || [])];
      const { data: profiles } = await supabase
        .from('profiles_public')
        .select('*')
        .in('id', userIds);

      // Get all messages
      const { data: messages } = await supabase
        .from('messages')
        .select('*')
        .in('chat_id', chatIds)
        .order('created_at', { ascending: true });

      // Build chat objects
      const enrichedChats: ChatWithParticipants[] = chatsData.map(chat => {
        const chatParticipants = allParticipants?.filter(p => p.chat_id === chat.id) || [];
        const participantProfiles = chatParticipants
          .map(cp => profiles?.find(p => p.id === cp.user_id))
          .filter(Boolean) as Profile[];
        
        const chatMessages = (messages?.filter(m => m.chat_id === chat.id) || []) as DbMessage[];
        const lastMessage = chatMessages[chatMessages.length - 1];

        return {
          ...chat,
          is_group: chat.is_group,
          participants: participantProfiles,
          messages: chatMessages,
          lastMessage,
          unreadCount: 0,
        };
      });

      // Sort by last message
      enrichedChats.sort((a, b) => {
        const aTime = a.lastMessage?.created_at || a.created_at;
        const bTime = b.lastMessage?.created_at || b.created_at;
        return new Date(bTime).getTime() - new Date(aTime).getTime();
      });

      setChats(enrichedChats);
      saveCachedChats(user.id, enrichedChats);
    } catch (error) {
      console.error('Error fetching chats:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchChats();
  }, [fetchChats]);

  // Realtime subscription for messages
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('messages-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'messages',
        },
        () => {
          fetchChats();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, fetchChats]);

  const sendMessage = async (
    chatId: string, 
    content: string | null, 
    type: 'text' | 'image' | 'audio' | 'file' = 'text',
    fileUrl: string | null = null,
    fileName: string | null = null
  ) => {
    if (!user) return;

    const { error } = await supabase.from('messages').insert({
      chat_id: chatId,
      sender_id: user.id,
      content,
      type,
      file_url: fileUrl,
      file_name: fileName,
    });

    if (error) {
      console.error('Error sending message:', error);
    }
  };

  const createChat = async (participantIds: string[], isGroup = false, groupName?: string) => {
    if (!user) return null;

    try {
      const { data, error } = await supabase.rpc('create_chat', {
        p_participant_ids: participantIds,
        p_is_group: isGroup,
        p_group_name: groupName || null,
      });

      if (error) {
        console.error('Error creating chat:', error.message, error.code);
        throw new Error(error.message);
      }

      await fetchChats();
      return data as string;
    } catch (error) {
      console.error('Error creating chat:', error);
      throw error;
    }
  };

  const findUserByEmail = async (email: string): Promise<Profile | null> => {
    const { data, error } = await supabase
      .rpc('find_user_by_email', { lookup_email: email.toLowerCase() });
    
    if (error) {
      console.error('Error finding user:', error);
      return null;
    }
    
    const user = Array.isArray(data) ? data[0] : data;
    
    if (!user || !user.id) return null;
    
    return {
      id: user.id,
      display_name: user.display_name,
      avatar_url: user.avatar_url,
      email: email.toLowerCase(),
      created_at: '',
      updated_at: '',
    } as Profile;
  };

  const deleteChat = async (chatId: string) => {
    if (!user) return;

    const { error } = await supabase
      .from('chat_participants')
      .delete()
      .eq('chat_id', chatId)
      .eq('user_id', user.id);

    if (error) {
      console.error('Error leaving chat:', error);
      return;
    }

    await fetchChats();
  };

  return {
    chats,
    loading,
    sendMessage,
    createChat,
    findUserByEmail,
    deleteChat,
    refetch: fetchChats,
  };
};
