import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { Profile } from '@/types/database';

export interface Story {
  id: string;
  user_id: string;
  content: string | null;
  media_url: string | null;
  media_type: 'image' | 'video' | 'text' | null;
  created_at: string;
  expires_at: string;
  user?: Profile;
  views_count?: number;
  viewed_by_me?: boolean;
}

export interface UserStories {
  user: Profile;
  stories: Story[];
  hasUnviewed: boolean;
}

export const useStories = () => {
  const { user } = useAuth();
  const [stories, setStories] = useState<Story[]>([]);
  const [userStories, setUserStories] = useState<UserStories[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchStories = useCallback(async () => {
    if (!user) return;

    try {
      // Get all non-expired stories
      const { data: storiesData, error: storiesError } = await supabase
        .from('stories')
        .select('*')
        .gt('expires_at', new Date().toISOString())
        .order('created_at', { ascending: false });

      if (storiesError) {
        console.error('Error fetching stories:', storiesError);
        return;
      }

      if (!storiesData || storiesData.length === 0) {
        setStories([]);
        setUserStories([]);
        setLoading(false);
        return;
      }

      // Get user profiles for story authors
      const userIds = [...new Set(storiesData.map((s) => s.user_id))];
      const { data: profiles } = await supabase
        .from('profiles_public')
        .select('*')
        .in('id', userIds);

      // Get which stories the current user has viewed
      const { data: views } = await supabase
        .from('story_views')
        .select('story_id')
        .eq('viewer_id', user.id);

      const viewedStoryIds = new Set(views?.map((v) => v.story_id) || []);

      // Enrich stories with user data and view status
      const enrichedStories: Story[] = storiesData.map((story) => ({
        ...story,
        media_type: story.media_type as Story['media_type'],
        user: profiles?.find((p) => p.id === story.user_id) as Profile | undefined,
        viewed_by_me: viewedStoryIds.has(story.id),
      }));

      setStories(enrichedStories);

      // Group stories by user
      const grouped = new Map<string, UserStories>();
      enrichedStories.forEach((story) => {
        if (!story.user) return;
        
        const existing = grouped.get(story.user_id);
        if (existing) {
          existing.stories.push(story);
          if (!story.viewed_by_me) {
            existing.hasUnviewed = true;
          }
        } else {
          grouped.set(story.user_id, {
            user: story.user,
            stories: [story],
            hasUnviewed: !story.viewed_by_me,
          });
        }
      });

      // Put current user's stories first
      const sortedUserStories = Array.from(grouped.values()).sort((a, b) => {
        if (a.user.id === user.id) return -1;
        if (b.user.id === user.id) return 1;
        // Then by has unviewed stories
        if (a.hasUnviewed && !b.hasUnviewed) return -1;
        if (!a.hasUnviewed && b.hasUnviewed) return 1;
        return 0;
      });

      setUserStories(sortedUserStories);
    } catch (error) {
      console.error('Error fetching stories:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchStories();
  }, [fetchStories]);

  // Subscribe to story changes
  useEffect(() => {
    const channel = supabase
      .channel('stories-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'stories',
        },
        () => {
          fetchStories();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchStories]);

  const createStory = async (
    content: string | null,
    mediaUrl: string | null,
    mediaType: 'image' | 'video' | 'text'
  ) => {
    if (!user) return null;

    const { data, error } = await supabase
      .from('stories')
      .insert({
        user_id: user.id,
        content,
        media_url: mediaUrl,
        media_type: mediaType,
      })
      .select()
      .single();

    if (error) {
      console.error('Error creating story:', error);
      return null;
    }

    await fetchStories();
    return data;
  };

  const viewStory = async (storyId: string) => {
    if (!user) return;

    await supabase
      .from('story_views')
      .upsert({
        story_id: storyId,
        viewer_id: user.id,
      }, {
        onConflict: 'story_id,viewer_id'
      });

    // Update local state
    setStories((prev) =>
      prev.map((s) => (s.id === storyId ? { ...s, viewed_by_me: true } : s))
    );
  };

  const deleteStory = async (storyId: string) => {
    if (!user) return;

    const { error } = await supabase
      .from('stories')
      .delete()
      .eq('id', storyId)
      .eq('user_id', user.id);

    if (error) {
      console.error('Error deleting story:', error);
      return;
    }

    await fetchStories();
  };

  const uploadStoryMedia = async (file: File): Promise<string | null> => {
    if (!user) return null;

    const fileExt = file.name.split('.').pop();
    const fileName = `${user.id}/${Date.now()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from('stories')
      .upload(fileName, file);

    if (uploadError) {
      console.error('Error uploading story media:', uploadError);
      return null;
    }

    const { data: { publicUrl } } = supabase.storage
      .from('stories')
      .getPublicUrl(fileName);

    return publicUrl;
  };

  return {
    stories,
    userStories,
    loading,
    createStory,
    viewStory,
    deleteStory,
    uploadStoryMedia,
    refetch: fetchStories,
  };
};
