import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

interface CallSignal {
  id: string;
  call_id: string;
  caller_id: string;
  callee_id: string;
  signal_type: 'offer' | 'answer' | 'ice-candidate' | 'hangup' | 'reject' | 'busy';
  signal_data: Record<string, unknown> | null;
  is_video: boolean;
  created_at: string;
}

interface IncomingCall {
  callId: string;
  callerId: string;
  callerName: string;
  callerAvatar: string;
  isVideo: boolean;
  offerSdp: string;
}

const ICE_SERVERS = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
];

export const useWebRTC = () => {
  const { user } = useAuth();
  const [incomingCall, setIncomingCall] = useState<IncomingCall | null>(null);
  const [isInCall, setIsInCall] = useState(false);
  const [callState, setCallState] = useState<'idle' | 'calling' | 'ringing' | 'connected'>('idle');
  
  const peerConnection = useRef<RTCPeerConnection | null>(null);
  const localStream = useRef<MediaStream | null>(null);
  const remoteStream = useRef<MediaStream | null>(null);
  const currentCallId = useRef<string | null>(null);
  const currentCalleeId = useRef<string | null>(null);

  const [localVideoRef, setLocalVideoRef] = useState<HTMLVideoElement | null>(null);
  const [remoteVideoRef, setRemoteVideoRef] = useState<HTMLVideoElement | null>(null);

  const cleanup = useCallback(() => {
    if (localStream.current) {
      localStream.current.getTracks().forEach((track) => track.stop());
      localStream.current = null;
    }
    if (peerConnection.current) {
      peerConnection.current.close();
      peerConnection.current = null;
    }
    remoteStream.current = null;
    currentCallId.current = null;
    currentCalleeId.current = null;
    setIsInCall(false);
    setCallState('idle');
  }, []);

  const sendSignal = useCallback(async (
    callId: string,
    calleeId: string,
    signalType: string,
    signalData: Record<string, unknown> | null,
    isVideo: boolean
  ) => {
    if (!user) return;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase.from('call_signals') as any).insert({
      call_id: callId,
      caller_id: user.id,
      callee_id: calleeId,
      signal_type: signalType,
      signal_data: signalData,
      is_video: isVideo,
    });
  }, [user]);

  const createPeerConnection = useCallback((isVideo: boolean) => {
    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

    pc.onicecandidate = (event) => {
      if (event.candidate && currentCallId.current && currentCalleeId.current) {
        sendSignal(
          currentCallId.current,
          currentCalleeId.current,
          'ice-candidate',
          { candidate: event.candidate.toJSON() },
          isVideo
        );
      }
    };

    pc.ontrack = (event) => {
      remoteStream.current = event.streams[0];
      if (remoteVideoRef) {
        remoteVideoRef.srcObject = event.streams[0];
      }
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected') {
        setCallState('connected');
      } else if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
        cleanup();
      }
    };

    peerConnection.current = pc;
    return pc;
  }, [sendSignal, remoteVideoRef, cleanup]);

  const startCall = useCallback(async (calleeId: string, isVideo: boolean) => {
    if (!user || isInCall) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: isVideo,
        audio: true,
      });
      localStream.current = stream;
      
      if (localVideoRef) {
        localVideoRef.srcObject = stream;
      }

      const callId = crypto.randomUUID();
      currentCallId.current = callId;
      currentCalleeId.current = calleeId;
      setIsInCall(true);
      setCallState('calling');

      const pc = createPeerConnection(isVideo);
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);

      await sendSignal(callId, calleeId, 'offer', { sdp: offer.sdp, type: offer.type }, isVideo);

      return callId;
    } catch (error) {
      console.error('Error starting call:', error);
      cleanup();
      return null;
    }
  }, [user, isInCall, localVideoRef, createPeerConnection, sendSignal, cleanup]);

  const answerCall = useCallback(async (callId: string, callerId: string, isVideo: boolean, offerSdp: string) => {
    if (!user) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: isVideo,
        audio: true,
      });
      localStream.current = stream;
      
      if (localVideoRef) {
        localVideoRef.srcObject = stream;
      }

      currentCallId.current = callId;
      currentCalleeId.current = callerId;
      setIsInCall(true);
      setCallState('connected');
      setIncomingCall(null);

      const pc = createPeerConnection(isVideo);
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      await pc.setRemoteDescription(new RTCSessionDescription({ type: 'offer', sdp: offerSdp }));
      
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);

      await sendSignal(callId, callerId, 'answer', { sdp: answer.sdp, type: answer.type }, isVideo);
    } catch (error) {
      console.error('Error answering call:', error);
      cleanup();
    }
  }, [user, localVideoRef, createPeerConnection, sendSignal, cleanup]);

  const rejectCall = useCallback(async () => {
    if (!incomingCall || !user) return;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await (supabase.from('call_signals') as any).insert({
      call_id: incomingCall.callId,
      caller_id: user.id,
      callee_id: incomingCall.callerId,
      signal_type: 'reject',
      signal_data: null,
      is_video: incomingCall.isVideo,
    });

    setIncomingCall(null);
  }, [incomingCall, user]);

  const endCall = useCallback(async () => {
    if (currentCallId.current && currentCalleeId.current && user) {
      await sendSignal(currentCallId.current, currentCalleeId.current, 'hangup', null, false);
    }
    cleanup();
  }, [user, sendSignal, cleanup]);

  const toggleMute = useCallback(() => {
    if (localStream.current) {
      const audioTrack = localStream.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        return !audioTrack.enabled;
      }
    }
    return false;
  }, []);

  const toggleVideo = useCallback(() => {
    if (localStream.current) {
      const videoTrack = localStream.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        return !videoTrack.enabled;
      }
    }
    return false;
  }, []);

  // Listen for incoming call signals
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('call-signals')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'call_signals',
          filter: `callee_id=eq.${user.id}`,
        },
        async (payload) => {
          const signal = payload.new as CallSignal;

          switch (signal.signal_type) {
            case 'offer':
              // Fetch caller info
              const { data: callerData } = await supabase
                .from('profiles_public')
                .select('*')
                .eq('id', signal.caller_id)
                .single();

              setIncomingCall({
                callId: signal.call_id,
                callerId: signal.caller_id,
                callerName: callerData?.display_name || 'Usuario',
                callerAvatar: callerData?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${signal.caller_id}`,
                isVideo: signal.is_video,
                offerSdp: (signal.signal_data as Record<string, unknown>)?.sdp as string || '',
              });
              break;

            case 'answer':
              if (peerConnection.current && signal.signal_data?.sdp) {
                await peerConnection.current.setRemoteDescription(
                  new RTCSessionDescription({
                    type: 'answer',
                    sdp: signal.signal_data.sdp as string,
                  })
                );
                setCallState('connected');
              }
              break;

            case 'ice-candidate':
              if (peerConnection.current && signal.signal_data?.candidate) {
                await peerConnection.current.addIceCandidate(
                  new RTCIceCandidate(signal.signal_data.candidate as RTCIceCandidateInit)
                );
              }
              break;

            case 'hangup':
            case 'reject':
              cleanup();
              break;
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, cleanup]);

  return {
    incomingCall,
    isInCall,
    callState,
    localStream: localStream.current,
    remoteStream: remoteStream.current,
    startCall,
    answerCall,
    rejectCall,
    endCall,
    toggleMute,
    toggleVideo,
    setLocalVideoRef,
    setRemoteVideoRef,
  };
};
