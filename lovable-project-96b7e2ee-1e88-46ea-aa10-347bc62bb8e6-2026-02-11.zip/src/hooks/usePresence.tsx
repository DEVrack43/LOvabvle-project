import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

interface UserPresence {
  user_id: string;
  status: 'online' | 'offline' | 'away';
  last_seen: string;
}

export const usePresence = () => {
  const { user } = useAuth();
  const [presenceMap, setPresenceMap] = useState<Map<string, UserPresence>>(new Map());

  const updateMyPresence = useCallback(async (status: 'online' | 'offline' | 'away') => {
    if (!user) return;

    const { error } = await supabase
      .from('user_presence')
      .upsert({
        user_id: user.id,
        status,
        last_seen: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }, {
        onConflict: 'user_id'
      });

    if (error) {
      console.error('Error updating presence:', error);
    }
  }, [user]);

  const fetchPresence = useCallback(async (userIds: string[]) => {
    if (userIds.length === 0) return;

    const { data, error } = await supabase
      .from('user_presence')
      .select('*')
      .in('user_id', userIds);

    if (error) {
      console.error('Error fetching presence:', error);
      return;
    }

    const newMap = new Map<string, UserPresence>();
    data?.forEach((p) => {
      newMap.set(p.user_id, p as UserPresence);
    });
    setPresenceMap(newMap);
  }, []);

  // Set online when component mounts, offline on unmount
  useEffect(() => {
    if (!user) return;

    updateMyPresence('online');

    // Set up heartbeat to keep presence alive
    const heartbeat = setInterval(() => {
      updateMyPresence('online');
    }, 30000); // Every 30 seconds

    // Handle page visibility
    const handleVisibilityChange = () => {
      if (document.hidden) {
        updateMyPresence('away');
      } else {
        updateMyPresence('online');
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Handle page unload
    const handleBeforeUnload = () => {
      // Use sendBeacon for reliable offline status
      const payload = JSON.stringify({
        user_id: user.id,
        status: 'offline',
        last_seen: new Date().toISOString(),
      });
      navigator.sendBeacon?.(`${import.meta.env.VITE_SUPABASE_URL}/rest/v1/user_presence?on_conflict=user_id`, payload);
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      clearInterval(heartbeat);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      updateMyPresence('offline');
    };
  }, [user, updateMyPresence]);

  // Subscribe to presence changes
  useEffect(() => {
    const channel = supabase
      .channel('presence-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_presence',
        },
        (payload) => {
          const newPresence = payload.new as UserPresence;
          if (newPresence?.user_id) {
            setPresenceMap((prev) => {
              const updated = new Map(prev);
              updated.set(newPresence.user_id, newPresence);
              return updated;
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const getPresence = (userId: string): UserPresence | undefined => {
    return presenceMap.get(userId);
  };

  const isOnline = (userId: string): boolean => {
    const presence = presenceMap.get(userId);
    return presence?.status === 'online';
  };

  return {
    presenceMap,
    fetchPresence,
    getPresence,
    isOnline,
    updateMyPresence,
  };
};

