import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

/**
 * Hook to generate signed URLs on-demand for files in the chat-files bucket.
 * This prevents issues with expired signed URLs in stored messages.
 * 
 * @param filePath - The file path in the chat-files bucket (not a signed URL)
 * @returns The current signed URL or null while loading
 */
export const useSignedUrl = (filePath: string | null) => {
  const [url, setUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!filePath) {
      setUrl(null);
      return;
    }

    // Check if it's already a full URL (legacy data with signed URLs)
    if (filePath.startsWith('http://') || filePath.startsWith('https://')) {
      setUrl(filePath);
      return;
    }

    const generateSignedUrl = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase.storage
          .from('chat-files')
          .createSignedUrl(filePath, 3600); // 1 hour expiry

        if (error) {
          console.error('Error generating signed URL:', error);
          setUrl(null);
        } else if (data) {
          setUrl(data.signedUrl);
        }
      } catch (error) {
        console.error('Error generating signed URL:', error);
        setUrl(null);
      } finally {
        setLoading(false);
      }
    };

    generateSignedUrl();
  }, [filePath]);

  return { url, loading };
};
