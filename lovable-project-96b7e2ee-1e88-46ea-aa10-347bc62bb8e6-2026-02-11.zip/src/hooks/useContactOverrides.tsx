import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

export interface ContactOverride {
  id: string;
  user_id: string;
  contact_id: string;
  custom_name: string | null;
  custom_avatar: string | null;
  created_at: string;
  updated_at: string;
}

export const useContactOverrides = () => {
  const { user } = useAuth();
  const [overrides, setOverrides] = useState<Map<string, ContactOverride>>(new Map());
  const [loading, setLoading] = useState(true);

  const fetchOverrides = useCallback(async () => {
    if (!user) {
      setOverrides(new Map());
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from('contact_overrides')
      .select('*')
      .eq('user_id', user.id);

    if (error) {
      console.error('Error fetching contact overrides:', error);
      setLoading(false);
      return;
    }

    const newMap = new Map<string, ContactOverride>();
    data?.forEach((override) => {
      newMap.set(override.contact_id, override as ContactOverride);
    });
    setOverrides(newMap);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchOverrides();
  }, [fetchOverrides]);

  const getOverride = useCallback((contactId: string): ContactOverride | undefined => {
    return overrides.get(contactId);
  }, [overrides]);

  const getDisplayName = useCallback((contactId: string, originalName: string | null): string => {
    const override = overrides.get(contactId);
    return override?.custom_name || originalName || 'Usuario';
  }, [overrides]);

  const getDisplayAvatar = useCallback((contactId: string, originalAvatar: string | null): string => {
    const override = overrides.get(contactId);
    return override?.custom_avatar || originalAvatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${contactId}`;
  }, [overrides]);

  const setOverride = useCallback(async (
    contactId: string, 
    customName: string | null, 
    customAvatar: string | null
  ): Promise<boolean> => {
    if (!user) return false;

    // Use upsert to handle both insert and update atomically
    const { error } = await supabase
      .from('contact_overrides')
      .upsert(
        {
          user_id: user.id,
          contact_id: contactId,
          custom_name: customName,
          custom_avatar: customAvatar,
        },
        { onConflict: 'user_id,contact_id' }
      );

    if (error) {
      console.error('Error saving contact override:', error);
      return false;
    }

    await fetchOverrides();
    return true;
  }, [user, fetchOverrides]);

  const removeOverride = useCallback(async (contactId: string): Promise<boolean> => {
    if (!user) return false;

    const existingOverride = overrides.get(contactId);
    if (!existingOverride) return true;

    const { error } = await supabase
      .from('contact_overrides')
      .delete()
      .eq('id', existingOverride.id);

    if (error) {
      console.error('Error removing contact override:', error);
      return false;
    }

    await fetchOverrides();
    return true;
  }, [user, overrides, fetchOverrides]);

  return {
    overrides,
    loading,
    getOverride,
    getDisplayName,
    getDisplayAvatar,
    setOverride,
    removeOverride,
    refetch: fetchOverrides,
  };
};
