import { useEffect, useCallback, useRef, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

export const useNotifications = () => {
  const { user } = useAuth();
  const permissionRef = useRef<NotificationPermission>('default');
  const [swRegistration, setSwRegistration] = useState<ServiceWorkerRegistration | null>(null);
  const [pushSubscribed, setPushSubscribed] = useState(false);
  const vapidPublicKeyRef = useRef<string | null>(null);

  useEffect(() => {
    if ('Notification' in window) {
      permissionRef.current = Notification.permission;
    }
  }, []);

  // Register Service Worker
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then((reg) => {
          setSwRegistration(reg);
          console.log('Service Worker registered');
        })
        .catch((err) => console.error('SW registration failed:', err));

      // Listen for messages from SW (e.g., OPEN_CHAT)
      navigator.serviceWorker.addEventListener('message', (event) => {
        if (event.data?.type === 'OPEN_CHAT') {
          // Dispatch custom event for the app to handle
          window.dispatchEvent(new CustomEvent('sw-open-chat', { detail: { chatId: event.data.chatId } }));
        }
      });
    }
  }, []);

  // Cache config for SW to use when replying
  const cacheConfigForSW = useCallback(async () => {
    if (!user) return;
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const cache = await caches.open('app-config');
      const config = {
        supabaseUrl: import.meta.env.VITE_SUPABASE_URL,
        supabaseKey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        userId: user.id,
        accessToken: session.access_token,
      };
      await cache.put('config', new Response(JSON.stringify(config)));
    } catch (e) {
      console.error('Failed to cache config for SW:', e);
    }
  }, [user]);

  useEffect(() => {
    cacheConfigForSW();
  }, [cacheConfigForSW]);

  // Update cached token when it changes
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(() => {
      cacheConfigForSW();
    });
    return () => subscription.unsubscribe();
  }, [cacheConfigForSW]);

  // Fetch VAPID public key
  const getVapidPublicKey = useCallback(async (): Promise<string | null> => {
    if (vapidPublicKeyRef.current) return vapidPublicKeyRef.current;

    try {
      const { data, error } = await supabase.functions.invoke('vapid-keys');
      if (error) throw error;
      vapidPublicKeyRef.current = data.publicKey;
      return data.publicKey;
    } catch (e) {
      console.error('Failed to get VAPID key:', e);
      return null;
    }
  }, []);

  // Subscribe to push notifications
  const subscribeToPush = useCallback(async (): Promise<boolean> => {
    if (!swRegistration || !user) return false;

    try {
      // Check existing subscription
      let subscription = await (swRegistration as any).pushManager.getSubscription();

      if (!subscription) {
        const publicKey = await getVapidPublicKey();
        if (!publicKey) return false;

        // Convert base64url to Uint8Array
        const padding = '='.repeat((4 - (publicKey.length % 4)) % 4);
        const base64 = (publicKey + padding).replace(/-/g, '+').replace(/_/g, '/');
        const rawData = atob(base64);
        const applicationServerKey = new Uint8Array(rawData.length);
        for (let i = 0; i < rawData.length; i++) {
          applicationServerKey[i] = rawData.charCodeAt(i);
        }

        subscription = await (swRegistration as any).pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey,
        });
      }

      // Store subscription in database
      const subscriptionJSON = subscription.toJSON();
      const { error } = await supabase
        .from('push_subscriptions' as any)
        .upsert({
          user_id: user.id,
          endpoint: subscriptionJSON.endpoint!,
          p256dh: subscriptionJSON.keys!.p256dh!,
          auth: subscriptionJSON.keys!.auth!,
        }, {
          onConflict: 'user_id,endpoint',
        });

      if (error) {
        console.error('Failed to store push subscription:', error);
        return false;
      }

      setPushSubscribed(true);
      return true;
    } catch (e) {
      console.error('Failed to subscribe to push:', e);
      return false;
    }
  }, [swRegistration, user, getVapidPublicKey]);

  const requestPermission = useCallback(async (): Promise<boolean> => {
    if (!('Notification' in window)) {
      console.warn('Este navegador no soporta notificaciones');
      return false;
    }

    if (Notification.permission === 'granted') {
      permissionRef.current = 'granted';
      // Also subscribe to push when permission is already granted
      await subscribeToPush();
      return true;
    }

    if (Notification.permission === 'denied') {
      return false;
    }

    const permission = await Notification.requestPermission();
    permissionRef.current = permission;

    if (permission === 'granted') {
      await subscribeToPush();
    }

    return permission === 'granted';
  }, [subscribeToPush]);

  // Auto-subscribe when SW is ready and permission is granted
  useEffect(() => {
    if (swRegistration && user && Notification.permission === 'granted' && !pushSubscribed) {
      subscribeToPush();
    }
  }, [swRegistration, user, pushSubscribed, subscribeToPush]);

  const showNotification = useCallback((title: string, options?: NotificationOptions) => {
    if (!('Notification' in window)) return;
    if (permissionRef.current !== 'granted') return;

    // Don't show if page is focused
    if (document.hasFocus()) return;

    // Use SW for notification if available (supports actions)
    if (swRegistration) {
      swRegistration.showNotification(title, {
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        ...options,
      });
      return;
    }

    try {
      const notification = new Notification(title, {
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        ...options,
      });
      notification.onclick = () => {
        window.focus();
        notification.close();
      };
      setTimeout(() => notification.close(), 5000);
    } catch (error) {
      console.error('Error showing notification:', error);
    }
  }, [swRegistration]);

  // Send push notification via edge function (for background delivery)
  const sendPushNotification = useCallback(async (
    recipientIds: string[],
    title: string,
    body: string,
    options: { icon?: string; tag?: string; chatId?: string; senderId?: string; type?: string } = {}
  ) => {
    try {
      await supabase.functions.invoke('send-push-notification', {
        body: {
          recipientIds,
          title,
          body,
          icon: options.icon,
          tag: options.tag || 'default',
          chatId: options.chatId,
          senderId: options.senderId,
          type: options.type || 'message',
        },
      });
    } catch (e) {
      console.error('Failed to send push notification:', e);
    }
  }, []);

  const notifyNewMessage = useCallback((senderName: string, messagePreview: string, avatarUrl?: string, chatId?: string, senderId?: string, recipientIds?: string[]) => {
    // Show local notification if app is open but not focused
    showNotification(senderName, {
      body: messagePreview,
      tag: `message-${chatId}`,
      icon: avatarUrl || '/favicon.ico',
    });

    // Send push notification for background delivery
    if (recipientIds && recipientIds.length > 0) {
      sendPushNotification(recipientIds, senderName, messagePreview, {
        icon: avatarUrl,
        tag: `message-${chatId}`,
        chatId,
        senderId,
        type: 'message',
      });
    }
  }, [showNotification, sendPushNotification]);

  const notifyIncomingCall = useCallback((callerName: string, isVideo: boolean, avatarUrl?: string) => {
    showNotification(`Llamada ${isVideo ? 'de video' : 'de voz'} entrante`, {
      body: `${callerName} te está llamando`,
      tag: 'incoming-call',
      requireInteraction: true,
      icon: avatarUrl || '/favicon.ico',
    });
  }, [showNotification]);

  const notifyNewStory = useCallback((userName: string, avatarUrl?: string, recipientIds?: string[]) => {
    showNotification('Nuevo estado', {
      body: `${userName} ha publicado un nuevo estado`,
      tag: 'new-story',
      icon: avatarUrl || '/favicon.ico',
    });

    if (recipientIds && recipientIds.length > 0) {
      sendPushNotification(recipientIds, 'Nuevo estado', `${userName} ha publicado un nuevo estado`, {
        icon: avatarUrl,
        tag: 'new-story',
        type: 'story',
      });
    }
  }, [showNotification, sendPushNotification]);

  return {
    permission: permissionRef.current,
    pushSubscribed,
    requestPermission,
    showNotification,
    notifyNewMessage,
    notifyIncomingCall,
    notifyNewStory,
    sendPushNotification,
  };
};
