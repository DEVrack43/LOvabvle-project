import { User, Chat, Message } from '@/types/chat';

export const currentUser: User = {
  id: 'user-1',
  name: 'Tú',
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=user1',
  status: 'online',
};

export const mockUsers: User[] = [
  {
    id: 'user-2',
    name: 'María García',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=maria',
    status: 'online',
  },
  {
    id: 'user-3',
    name: 'Carlos López',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=carlos',
    status: 'offline',
    lastSeen: new Date(Date.now() - 1000 * 60 * 30),
  },
  {
    id: 'user-4',
    name: 'Ana Martínez',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ana',
    status: 'online',
  },
  {
    id: 'user-5',
    name: 'Pedro Sánchez',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=pedro',
    status: 'away',
  },
  {
    id: 'user-6',
    name: 'Laura Fernández',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=laura',
    status: 'online',
  },
];

const createMessage = (
  id: string,
  content: string,
  senderId: string,
  minutesAgo: number,
  status: Message['status'] = 'read'
): Message => ({
  id,
  content,
  senderId,
  timestamp: new Date(Date.now() - 1000 * 60 * minutesAgo),
  status,
  type: 'text',
});

export const mockChats: Chat[] = [
  {
    id: 'chat-1',
    participants: [currentUser, mockUsers[0]],
    messages: [
      createMessage('m1', '¡Hola! ¿Cómo estás?', 'user-2', 120),
      createMessage('m2', '¡Muy bien! ¿Y tú?', 'user-1', 115),
      createMessage('m3', 'Genial, trabajando en un nuevo proyecto 💻', 'user-2', 110),
      createMessage('m4', '¡Qué interesante! Cuéntame más', 'user-1', 105),
      createMessage('m5', 'Es una app de mensajería como WhatsApp', 'user-2', 5, 'delivered'),
    ],
    unreadCount: 1,
    isGroup: false,
  },
  {
    id: 'chat-2',
    participants: [currentUser, mockUsers[1]],
    messages: [
      createMessage('m6', '¿Quedamos mañana para el café?', 'user-1', 60),
      createMessage('m7', '¡Claro! A las 10 está bien', 'user-3', 55),
    ],
    unreadCount: 0,
    isGroup: false,
  },
  {
    id: 'chat-3',
    participants: [currentUser, mockUsers[2]],
    messages: [
      createMessage('m8', 'Acabo de ver las fotos del viaje 📸', 'user-4', 180),
      createMessage('m9', '¡Son increíbles!', 'user-1', 175),
      createMessage('m10', 'Gracias! El próximo viaje vamos juntos', 'user-4', 170),
    ],
    unreadCount: 0,
    isGroup: false,
  },
  {
    id: 'chat-4',
    participants: [currentUser, mockUsers[0], mockUsers[1], mockUsers[2]],
    messages: [
      createMessage('m11', '¿Alguien para la reunión de hoy?', 'user-2', 30),
      createMessage('m12', 'Yo puedo a las 15:00', 'user-3', 25),
      createMessage('m13', 'Perfecto para mí', 'user-1', 20),
      createMessage('m14', '¡Genial! Nos vemos entonces 🎉', 'user-4', 15),
    ],
    unreadCount: 2,
    isGroup: true,
    groupName: 'Equipo de Trabajo',
    groupAvatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=team',
  },
  {
    id: 'chat-5',
    participants: [currentUser, mockUsers[3]],
    messages: [
      createMessage('m15', '¿Tienes el documento que te pedí?', 'user-5', 300),
      createMessage('m16', 'Sí, te lo envío ahora', 'user-1', 295),
    ],
    unreadCount: 0,
    isGroup: false,
  },
];
