export interface Profile {
  id: string;
  email: string;
  display_name: string | null;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface DbChat {
  id: string;
  is_group: boolean;
  group_name: string | null;
  group_avatar: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ChatParticipant {
  id: string;
  chat_id: string;
  user_id: string;
  joined_at: string;
}

export interface DbMessage {
  id: string;
  chat_id: string;
  sender_id: string;
  content: string | null;
  type: 'text' | 'image' | 'audio' | 'file';
  file_url: string | null;
  file_name: string | null;
  status: 'sent' | 'delivered' | 'read';
  created_at: string;
}

export interface ChatWithParticipants extends DbChat {
  participants: Profile[];
  messages: DbMessage[];
  lastMessage?: DbMessage;
  unreadCount: number;
}
